"""用 Streamlit AppTest 真正模拟点击「运行」按钮，触发 run_pipeline，
捕获任何运行时异常（import / 图表 / 数据处理），确保 demo 端到端可跑。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from streamlit.testing.v1 import AppTest  # noqa: E402

at = AppTest.from_file("app.py", default_timeout=240)
at.run()
print("== 初始加载异常 ==", at.exception)

# 股票池：选「自定义代码」→ 填 3 只加速（避免 10 只全量耗时）
try:
    pool_sel = at.selectbox[0]
    print("pool selectbox label:", pool_sel.label, "| value:", pool_sel.value)
    pool_sel.set_value("自定义代码（逗号分隔）").run()
    ti = at.text_input[0]
    ti.set_value("600519.SH,601318.SH,600036.SH").run()
    print("pool set to:", at.text_input[0].value)
except Exception as e:
    print("set pool failed:", e)

# LLM 模型切到「离线 Mock」，排除限流/网络干扰，专测页面逻辑
try:
    for sb in at.selectbox:
        if sb.label == "LLM 模型":
            sb.set_value("离线 Mock（不调用）").run()
            print("LLM model set to:", sb.value)
            break
except Exception as e:
    print("set llm model failed:", e)

btn = [b for b in at.button if "运行" in b.label]
print("found run button:", bool(btn))
btn[0].click().run()

exc = at.exception
print("== 点击运行后异常 ==", exc)
if exc:
    import traceback
    try:
        if hasattr(exc, "__traceback__"):
            traceback.print_exception(type(exc), exc, exc.__traceback__)
        else:
            for e in exc:
                traceback.print_exception(type(e), e, e.__traceback__)
    except Exception:
        pass

# 检查报告是否生成
mds = [m.value for m in at.markdown]
has_report = any(m and ("投研" in m or "因子" in m) for m in mds)
print("== 报告内容存在 ==", has_report)
print("== markdown 段落数 ==", len(mds))
print("DONE")
