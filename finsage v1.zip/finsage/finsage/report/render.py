"""报告渲染：Markdown -> 自包含 HTML（marked.js CDN，零额外依赖）。"""

from __future__ import annotations

from ..config import REPORT_DIR


def render_html(markdown_text: str, title: str = "FinSage 投研报告") -> str:
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  body {{ font-family: -apple-system, "Microsoft YaHei", "PingFang SC", sans-serif;
         max-width: 920px; margin: 24px auto; padding: 0 20px; color: #222; line-height: 1.6; }}
  h1, h2 {{ border-bottom: 1px solid #eee; padding-bottom: 6px; }}
  table {{ border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 14px; }}
  th, td {{ border: 1px solid #ddd; padding: 6px 10px; text-align: center; }}
  th {{ background: #f5f7fa; }}
  code {{ background: #f2f2f2; padding: 1px 4px; border-radius: 3px; }}
  blockquote {{ color: #666; border-left: 3px solid #ccc; margin: 8px 0; padding-left: 12px; }}
</style>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
</head>
<body>
<div id="content"></div>
<script type="text/markdown" id="md">{markdown_text}</script>
<script>
  document.getElementById('content').innerHTML =
    marked.parse(document.getElementById('md').textContent);
</script>
</body>
</html>"""


def save_report(markdown_text: str, name: str = "finsage_report") -> dict:
    md_path = REPORT_DIR / f"{name}.md"
    html_path = REPORT_DIR / f"{name}.html"
    md_path.write_text(markdown_text, encoding="utf-8")
    html_path.write_text(render_html(markdown_text), encoding="utf-8")
    return {"md": str(md_path), "html": str(html_path)}
