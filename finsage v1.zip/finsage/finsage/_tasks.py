"""后台任务表：让投研链路在后台线程执行，不被 Streamlit rerun 打断。

背景
----
Streamlit 每次 rerun 都会重新执行 app.py，模块级变量随之重置；
而**用户点击任何 widget 都会触发 rerun 并中断当前正在执行的脚本**——
所以链路若在主线程同步执行，用户一碰侧边栏就会被掐断、结果全丢。

方案
----
- 状态放**独立模块**（Python import 只执行一次，跨 rerun 存活）；
- 真正耗时的 run_pipeline 跑在 daemon 线程里，不碰任何 st.* 指令；
- 主线程只读状态、渲染进度、定时 rerun 刷新；
- 用户点侧边栏 → 仅主线程 rerun → 后台线程继续跑，进度不丢。
"""

from __future__ import annotations

import threading
import time
import uuid

_LOCK = threading.Lock()
TASKS: dict = {}


def create(params: dict) -> str:
    """新建任务，返回 task_id。"""
    tid = uuid.uuid4().hex[:8]
    with _LOCK:
        TASKS[tid] = {
            "params": params,
            "status": "running",     # running / done / error
            "step": 0,
            "total": 6,
            "lines": [],             # [(step, label), ...]
            "result": None,
            "error": None,
            "t0": time.time(),
            "t_end": None,
        }
    return tid


def get(tid: str | None) -> dict | None:
    """读取任务快照（浅拷贝，避免主线程遍历时被子线程改动）。"""
    if not tid:
        return None
    with _LOCK:
        t = TASKS.get(tid)
        if t is None:
            return None
        return {**t, "lines": list(t["lines"])}


def add_line(tid: str, step: int, total: int, label: str) -> None:
    """追加一条阶段完成记录（加锁，避免读-改-写竞态）。"""
    with _LOCK:
        t = TASKS.get(tid)
        if t is None:
            return
        t["lines"].append((step, label))
        t["step"] = step
        t["total"] = total


def finish(tid: str, result=None, error: str | None = None) -> None:
    with _LOCK:
        t = TASKS.get(tid)
        if t is None:
            return
        t["status"] = "error" if error else "done"
        t["result"] = result
        t["error"] = error
        t["t_end"] = time.time()


def has_running(tid: str | None) -> bool:
    t = get(tid)
    return bool(t and t["status"] == "running")
