"""FinSage 命令行入口。

示例：
  python -m finsage --pool HS300 --start 2025-01-01 --end 2025-12-31 --source akshare
  python -m finsage --pool 600519.SH,000858.SZ --source synthetic --top-n 3
  python -m finsage --no-langgraph        # 强制使用兜底编排器
"""

from __future__ import annotations

import argparse
import json
import sys

from .config import DEFAULT_POOL, FACTOR_NAMES
from .orchestrator import run_pipeline
from .report import save_report


def _resolve_pool(spec: str):
    spec = spec.strip()
    if spec.upper() in ("HS300", "沪深300", "DEFAULT"):
        return list(DEFAULT_POOL)
    if spec.upper() in ("ZZ500", "中证500"):
        return [
            "600031.SH", "600585.SH", "600837.SH", "600893.SH", "601066.SH",
            "000001.SZ", "000063.SZ", "000651.SZ", "002415.SZ", "300059.SZ",
        ]
    return [c.strip() for c in spec.split(",") if c.strip()]


def main(argv=None):
    p = argparse.ArgumentParser(prog="finsage", description="FinSage 多智能体金融投研决策系统")
    p.add_argument("--pool", default="HS300", help="股票池：HS300 / ZZ500 / 逗号分隔代码")
    p.add_argument("--start", default="2025-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--top-n", type=int, default=5)
    p.add_argument("--source", default="akshare", choices=["akshare", "synthetic"])
    p.add_argument("--news-limit", type=int, default=20)
    p.add_argument("--no-langgraph", action="store_true", help="强制使用兜底编排器")
    p.add_argument("--out", default="finsage_report", help="报告文件名（不含扩展名）")
    p.add_argument("--quiet", action="store_true", help="不打印完整报告")
    p.add_argument("--json", action="store_true", help="输出结构化 JSON 摘要")
    args = p.parse_args(argv)

    pool = _resolve_pool(args.pool)
    state = run_pipeline(
        pool=pool, start=args.start, end=args.end, top_n=args.top_n,
        data_source=args.source, news_limit=args.news_limit,
        use_langgraph=not args.no_langgraph,
    )

    if args.json:
        summary = {
            "pool": pool, "start": args.start, "end": args.end,
            "dynamic_weights": state.get("research", {}).get("dynamic_weights"),
            "ranking": state.get("research", {}).get("ranking"),
            "backtest": {k: state.get("backtest", {}).get(k) for k in
                         ["dynamic", "static_equalweight", "equal_all"]},
            "risk_count": state.get("risks", {}).get("count"),
            "used_torch": state.get("research", {}).get("used_torch"),
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    else:
        if not args.quiet:
            print(state.get("report", ""))
        paths = save_report(state.get("report", ""), name=args.out)
        bt = state.get("backtest", {})
        print("\n" + "=" * 56)
        print("回测对比：动态权重 vs 静态等权")
        for k, label in [("dynamic", "动态因子权重"), ("static_equalweight", "静态等权因子"),
                         ("equal_all", "全样本等权")]:
            m = bt.get(k, {})
            print(f"  {label:<10} 累计 {m.get('total_return',0):.1%} | "
                  f"年化 {m.get('ann_return',0):.1%} | 回撤 {m.get('max_drawdown',0):.1%} | "
                  f"夏普 {m.get('sharpe',0):.2f}")
        print(f"报告已保存：{paths['md']}\n            {paths['html']}")
        print("=" * 56)

    return 0


if __name__ == "__main__":
    sys.exit(main())
