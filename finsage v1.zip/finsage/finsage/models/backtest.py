"""回测：动态因子权重组合 vs 静态等权基准。

策略：
  - 动态策略：每个再平衡日 k，用"截至 k 的滚动窗口"估计各因子 rank-IC，
    按 regime 做防御倾斜后 softmax 得到动态权重 w(k)，
    综合得分 = Σ w_f(k)·z_f，选 Top-N 等权持有至下一再平衡日。
  - 静态基准 A：静态等权因子（传统基准）。
  - 静态基准 B：全股票等权买入持有（朴素基准）。

输出累计收益、最大回撤、夏普，用于量化"动态配置是否优于静态等权"。
"""

from __future__ import annotations

import numpy as np

FACTOR_NAMES = ["size", "value", "momentum", "volatility", "quality"]


def _metrics(equity: np.ndarray):
    eq = np.array(equity, dtype=float)
    rets = np.diff(eq) / eq[:-1]
    rets = rets[~np.isnan(rets)]
    if len(rets) == 0:
        return {"total_return": 0.0, "max_drawdown": 0.0, "sharpe": 0.0, "ann_return": 0.0}
    total = eq[-1] / eq[0] - 1
    peak = np.maximum.accumulate(eq)
    dd = (eq - peak) / peak
    max_dd = float(dd.min())
    ann = (1 + total) ** (12 / len(rets)) - 1 if len(rets) else 0.0
    vol = rets.std()
    sharpe = float((rets.mean() / vol) * np.sqrt(12)) if vol > 1e-12 else 0.0
    return {
        "total_return": float(total),
        "max_drawdown": max_dd,
        "sharpe": sharpe,
        "ann_return": float(ann),
    }


def dynamic_weights_at(factor_mat, period_ret_mat, t, W=6):
    """截至时点 t 的动态因子权重：滚动窗口因子 IC + regime 倾斜（softmax）。

    与 LSTM-Attention 的"特征注意力"同构——都是对五类因子的重要性加权，
    只是用可解释的信息系数(IC)显式表达，并随市场状态(regime)切换倾斜方向。
    """
    lo = max(0, t - W + 1)
    # 因子日期 j 的前向收益存于 period_ret_mat[:, j]（仅 0..T-2 有效），
    # 故窗口取因子日期 [lo, t-1] 与对应收益 [lo, t-1] 严格对齐。
    f_win = factor_mat[:, lo : t, :]              # (N, w, 5)
    r_win = period_ret_mat[:, lo : t]             # (N, w) 与因子窗口对齐的下期收益
    ns, w, F = f_win.shape
    ics = []
    for f in range(F):
        xs = f_win[:, :, f].reshape(-1)
        ys = r_win.reshape(-1)
        if len(xs) == len(ys) and xs.std() > 1e-9 and ys.std() > 1e-9:
            ic = np.corrcoef(xs, ys)[0, 1]
        else:
            ic = 0.0
        ics.append(0.0 if np.isnan(ic) else ic)
    ics = np.array(ics)
    # regime：窗口内市场（等权）波动 vs 全样本
    market_std = r_win.mean(axis=0).std() if w > 1 else 0.0
    full_std = period_ret_mat.std()
    if full_std > 0 and market_std > full_std * 1.2:
        ics[3] += 0.15   # 防御 regime：低波动
        ics[4] += 0.10   # 质量
    ics = ics - ics.min() + 1e-3
    return np.exp(ics) / np.exp(ics).sum()


def _dynamic_weights_trailing(factor_mat, period_ret_mat, k, W=6):
    """兼容旧调用的包装：返回截至 k 的动态权重。"""
    return dynamic_weights_at(factor_mat, period_ret_mat, k, W)


def run_backtest(factor_mat, period_ret_mat, stock_list, top_n=5,
                 static_weights=None):
    """factor_mat: (N, K, 5)；period_ret_mat: (N, K-1)。返回对比结果 dict。"""
    factor_mat = np.asarray(factor_mat, dtype=float)
    period_ret_mat = np.asarray(period_ret_mat, dtype=float)
    N, K, F = factor_mat.shape
    Kp = period_ret_mat.shape[1]
    if static_weights is None:
        static_weights = np.ones(F) / F

    dyn_eq = [1.0]
    static_eq = [1.0]
    equal_eq = [1.0]
    dyn_w_series = []

    for k in range(Kp):
        w_dyn = _dynamic_weights_trailing(factor_mat, period_ret_mat, k)
        dyn_w_series.append(w_dyn)
        scores_dyn = factor_mat[:, k, :] @ w_dyn
        scores_sta = factor_mat[:, k, :] @ static_weights

        top = np.argsort(scores_dyn)[::-1][:top_n]
        pr = period_ret_mat[:, k]
        # 处理缺失
        pr_safe = np.nan_to_num(pr, nan=0.0)

        dyn_ret = float(np.mean(pr_safe[top]))
        sta_top = np.argsort(scores_sta)[::-1][:top_n]
        sta_ret = float(np.mean(pr_safe[sta_top]))
        eq_ret = float(np.mean(pr_safe))

        dyn_eq.append(dyn_eq[-1] * (1 + dyn_ret))
        static_eq.append(static_eq[-1] * (1 + sta_ret))
        equal_eq.append(equal_eq[-1] * (1 + eq_ret))

    result = {
        "stocks": stock_list,
        "top_n": top_n,
        "n_dates": Kp,
        "dynamic": {"equity": dyn_eq, **_metrics(dyn_eq)},
        "static_equalweight": {"equity": static_eq, **_metrics(static_eq)},
        "equal_all": {"equity": equal_eq, **_metrics(equal_eq)},
        "dynamic_weights_last": dyn_w_series[-1].tolist() if dyn_w_series else static_weights.tolist(),
        "dynamic_weights_series": dyn_w_series,
    }
    return result
