"""LSTM-Attention 融合模型。

架构（双通道 + 双维注意力）：
  - 因子通道：LSTM 编码 (T, 5) 因子时序 → 隐藏态 H_f
  - 情绪通道：LSTM 编码 (T, 1) 情绪时序 → 隐藏态 H_s
  - 时序注意力（temporal）：对时间步加权，得到上下文向量 c_f / c_s
  - 特征注意力（feature）：在 5 个因子维度上做注意力，时间平均后得到
    因子重要性向量 → softmax 即"动态因子权重"
  - 打分头：融合 c_f, c_s 预测下期收益

动态因子权重 = softmax(特征注意力)，天然随市场状态（输入）变化，
正是"因子配置 ≠ 静态等权"主张的工程落地。

PyTorch 优先；若不可用则用 numpy 启发式兜底（regime-conditioned IC 倾斜）。
"""

from __future__ import annotations

import importlib.util
import numpy as np

TORCH_AVAILABLE = importlib.util.find_spec("torch") is not None

N_FACTORS = 5  # size, value, momentum, volatility, quality


if TORCH_AVAILABLE:
    import torch
    import torch.nn as nn

    class LSTMAttention(nn.Module):
        def __init__(self, n_factors=N_FACTORS, n_sent=1, hidden=16):
            super().__init__()
            self.hidden = hidden
            self.factor_lstm = nn.LSTM(n_factors, hidden, batch_first=True)
            self.sent_lstm = nn.LSTM(n_sent, hidden, batch_first=True)
            self.temp_f = nn.Linear(hidden, 1)
            self.temp_s = nn.Linear(hidden, 1)
            self.feat_proj = nn.Linear(hidden, n_factors)
            self.head = nn.Sequential(
                nn.Linear(hidden * 2, 16), nn.ReLU(), nn.Linear(16, 1)
            )

        def forward(self, x_f, x_s):
            hf, _ = self.factor_lstm(x_f)          # (B,T,h)
            hs, _ = self.sent_lstm(x_s)            # (B,T,h)
            af = torch.softmax(self.temp_f(hf), dim=1)
            cf = (af * hf).sum(dim=1)              # (B,h)
            a_s = torch.softmax(self.temp_s(hs), dim=1)
            cs = (a_s * hs).sum(dim=1)             # (B,h)
            feat = torch.softmax(self.feat_proj(hf), dim=2)  # (B,T,F)
            feat_w = feat.mean(dim=1)              # (B,F) 因子重要性
            score = self.head(torch.cat([cf, cs], dim=1)).squeeze(-1)
            return score, feat_w


def _build_sequences(factor_mat, sent_mat, lookback=6):
    """factor_mat: (N_stock, T, 5)；sent_mat: (N_stock, T, 1)。
    返回 X_f (M,T,5), X_s (M,T,1), idx (M,2) -> (stock_i, t)。"""
    ns, T, _ = factor_mat.shape
    # 目标为 t→t+1 的前向收益，故 t 最大取 T-2（returns_next 仅 K-1 列）
    Xf, Xs, idx = [], [], []
    for i in range(ns):
        for t in range(lookback - 1, T - 1):
            Xf.append(factor_mat[i, t - lookback + 1 : t + 1])
            Xs.append(sent_mat[i, t - lookback + 1 : t + 1])
            idx.append((i, t))
    return np.array(Xf), np.array(Xs), idx


def compute_dynamic_weights_heuristic(factor_panel_dates, factor_mat, sent_mat,
                                      returns_next, regime_high_vol):
    """numpy 兜底：基于因子历史 rank-IC 的 regime 倾斜权重。

    factor_mat: (N,T,5)；returns_next: (N,T) 下期收益；
    regime_high_vol: bool，高波动 regime 下 defensive 倾斜。
    """
    ns, T, F = factor_mat.shape
    Tret = returns_next.shape[1]  # 前向收益仅有 T-1 列
    ics = []
    for f in range(F):
        xs, ys = [], []
        for i in range(ns):
            for t in range(Tret):
                xs.append(factor_mat[i, t, f])
                ys.append(returns_next[i, t])
        xs = np.array(xs); ys = np.array(ys)
        if xs.std() > 1e-9 and ys.std() > 1e-9:
            ic = np.corrcoef(xs, ys)[0, 1]
        else:
            ic = 0.0
        ics.append(ic)
    ics = np.array(ics)
    w = ics.copy()
    if regime_high_vol:
        # 防御：提升低波动、质量权重
        w[3] += 0.15   # volatility（已对齐：越高越优=低波动）
        w[4] += 0.10   # quality
    w = w - w.min() + 1e-3
    return (np.exp(w) / np.exp(w).sum()).tolist()


def train_and_extract(factor_mat, sent_mat, returns_next, lookback=6,
                      epochs=40, lr=1e-3, seed=42):
    """训练模型并提取"最新时点的动态因子权重"与"最新样本打分"。

    返回 dict: {dynamic_weights: [5], latest_scores: [N], used_torch: bool}
    factor_mat: (N,T,5) 已标准化因子 z；sent_mat: (N,T,1)；returns_next: (N,T)
    """
    ns, T, F = factor_mat.shape
    if not TORCH_AVAILABLE or T < lookback + 1:
        # 兜底
        regime_high_vol = bool(np.nanstd(returns_next) > 0.04)
        w = compute_dynamic_weights_heuristic(
            None, factor_mat, sent_mat, returns_next, regime_high_vol
        )
        # 分数：用静态等权加权因子 z 近似
        scores = (factor_mat[:, -1, :] * np.array(w)).sum(axis=1)
        return {"dynamic_weights": w, "latest_scores": scores.tolist(), "used_torch": False}

    torch.manual_seed(seed)
    np.random.seed(seed)
    Xf, Xs, idx = _build_sequences(factor_mat, sent_mat, lookback)
    if len(Xf) < 8:
        regime_high_vol = bool(np.nanstd(returns_next) > 0.04)
        w = compute_dynamic_weights_heuristic(None, factor_mat, sent_mat, returns_next, regime_high_vol)
        scores = (factor_mat[:, -1, :] * np.array(w)).sum(axis=1)
        return {"dynamic_weights": w, "latest_scores": scores.tolist(), "used_torch": False}

    # 构造监督目标：idx 对应 (i,t) 的下期收益
    y = np.array([returns_next[i, t] for (i, t) in idx], dtype=np.float32)
    y_std = y.std() if y.std() > 1e-9 else 1.0
    y_n = (y - y.mean()) / y_std

    Xf_t = torch.tensor(Xf, dtype=torch.float32)
    Xs_t = torch.tensor(Xs, dtype=torch.float32)
    y_t = torch.tensor(y_n, dtype=torch.float32)

    model = LSTMAttention()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    model.train()
    for _ in range(epochs):
        opt.zero_grad()
        pred, _ = model(Xf_t, Xs_t)
        loss = loss_fn(pred, y_t)
        loss.backward()
        opt.step()

    model.eval()
    with torch.no_grad():
        # 全样本提取特征注意力，最新时点取最后一个样本
        _, feat_w_all = model(Xf_t, Xs_t)
        last_i, last_t = idx[-1]
        # 找到该 (i,t) 在 batch 中的位置
        pos = [k for k, (i, t) in enumerate(idx) if (i, t) == (last_i, last_t)][-1]
        feat_w = torch.softmax(feat_w_all[pos], dim=0).numpy()
        # 最新样本打分：用模型对最新时刻每个股票打分
        # 取每个股票最后 lookback 窗口
        Xf_last, Xs_last = [], []
        for i in range(ns):
            Xf_last.append(factor_mat[i, -lookback:, :])
            Xs_last.append(sent_mat[i, -lookback:, :])
        Xf_last = torch.tensor(np.array(Xf_last), dtype=torch.float32)
        Xs_last = torch.tensor(np.array(Xs_last), dtype=torch.float32)
        scores, _ = model(Xf_last, Xs_last)
        scores = scores.numpy()

    return {
        "dynamic_weights": feat_w.tolist(),
        "latest_scores": scores.tolist(),
        "used_torch": True,
    }
