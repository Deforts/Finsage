"""LLM 客户端：OpenAI 兼容接口 + 自动 Mock 兜底。

设计要点：
- 不依赖 openai SDK，用标准库 urllib 直接 POST 到 /chat/completions，
  降低依赖体积，且天然兼容通义千问 / 智谱 GLM / 中转站兼容模式。
- 推理模型（如 glm-5.3-flash）会把思考过程放进 reasoning_tokens，
  正式答案仍在 content；部分模型会把 <think>...</think> 混进 content，
  故统一做 _clean 后处理。
- 当未配置 API Key 时抛出 LLMUnavailable，由调用方（各 Agent）捕获并
  使用确定性 fallback，保证离线可跑。
- 限流（429/407）与超时自动退避重试，提升演示稳定性。
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import List, Optional

from .config import LLMConfig


class LLMUnavailable(Exception):
    """未配置可用 LLM Key 时抛出，调用方应降级到 fallback。"""


@dataclass
class Message:
    role: str           # system | user | assistant
    content: str


_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)


def _clean(text: str) -> str:
    """剥离推理模型的 <think> 噪声并规整空白。"""
    if not text:
        return ""
    text = _THINK_RE.sub("", text)
    text = re.sub(r"</?think>", "", text, flags=re.IGNORECASE)
    return text.strip()


def _post(base_url: str, api_key: str, payload: dict, timeout: int,
         retries: int = 3) -> str:
    url = base_url.rstrip("/") + "/chat/completions"
    data = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    last_err = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = json.loads(resp.read().decode("utf-8"))
            content = body["choices"][0]["message"]["content"]
            return _clean(content)
        except urllib.error.HTTPError as e:
            code = e.code
            last_err = f"HTTP_{code}"
            # 限流：退避后重试
            if code in (429, 407):
                time.sleep(2 + attempt * 3)
                continue
            # 其他 HTTP 错误（如模型不可用）直接抛出，不重试
            raise
        except Exception as e:  # 超时 / 网络抖动
            last_err = repr(e)
            if attempt < retries - 1:
                time.sleep(2 + attempt * 2)
                continue
            raise
    raise RuntimeError(f"LLM 请求失败（已重试 {retries} 次）：{last_err}")


class LLMClient:
    """极简 OpenAI 兼容聊天客户端。"""

    def __init__(self, cfg: Optional[LLMConfig] = None):
        from .config import CONFIG

        self.cfg = cfg or CONFIG.llm

    @property
    def available(self) -> bool:
        return self.cfg.enabled

    def chat(
        self,
        messages: List[Message],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        if not self.cfg.enabled:
            raise LLMUnavailable(
                f"未检测到 LLM API Key（provider={self.cfg.provider}）。"
                "请配置 DASHSCOPE_API_KEY / ZHIPU_API_KEY / OPENAI_API_KEY，"
                "或忽略此提示使用各 Agent 的确定性 fallback。"
            )
        payload = {
            "model": self.cfg.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature if temperature is not None else self.cfg.temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.cfg.max_tokens,
        }
        return _post(
            self.cfg.base_url, self.cfg.api_key, payload, self.cfg.timeout
        )

    def complete(self, system: str, user: str, **kwargs) -> str:
        return self.chat([Message("system", system), Message("user", user)], **kwargs)


# 便捷单例
def get_client() -> LLMClient:
    return LLMClient()
