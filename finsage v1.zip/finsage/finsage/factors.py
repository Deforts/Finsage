"""因子计算：五类风格因子的原始值与截面标准化。

因子已做方向对齐——取值越高代表越"优"：
  size        = -log(市值)            小盘溢价，市值越小越优
  value       = 1/PE（随价格动态）    估值越低越优
  momentum    = 过去 N 日收益(跳过近5日) 动量越强越优
  volatility  = - realized vol        波动越低越优
  quality     = ROE                   盈利质量越高越优

截面 z-score 在 FactorAgent 中对股票池统一标准化，使不同量纲可比。
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def compute_factor_raw(prices: pd.DataFrame, fund: dict, as_of,
                       mom_lookback: int = 60, vol_lookback: int = 20) -> dict:
    sub = prices.loc[:as_of]
    if len(sub) < vol_lookback + 5:
        return {}
    close = sub["close"]
    last = close.iloc[-1]

    # size：用最新市值按价格比缩放，得到 as_of 时点的市值代理
    mcap = fund.get("market_cap", 1e10) * (last / close.iloc[-1]) if close.iloc[-1] else fund.get("market_cap", 1e10)
    size_raw = -np.log(max(mcap, 1e8))

    # value：EP 随价格反向变动
    pe = max(fund.get("pe", 15.0), 1e-6)
    ep = (1.0 / pe) * (last / close.iloc[-1])
    value_raw = ep

    # momentum：跳过最近 5 日，避免短期反转干扰
    if len(sub) > mom_lookback + 5:
        mom = close.iloc[-5] / close.iloc[-(5 + mom_lookback)] - 1.0
    else:
        mom = close.iloc[-1] / close.iloc[0] - 1.0

    # volatility：近 vol_lookback 日收益标准差
    rets = close.pct_change().dropna()
    vol = rets.iloc[-vol_lookback:].std(ddof=0) if len(rets) >= vol_lookback else rets.std(ddof=0)
    vol = 0.0 if pd.isna(vol) else float(vol)

    # quality
    quality_raw = float(fund.get("roe", 0.10))

    return {
        "size": float(size_raw),
        "value": float(value_raw),
        "momentum": float(mom),
        "volatility": float(-vol),
        "quality": float(quality_raw),
    }


def zscore_series(values: dict) -> dict:
    """对一组股票的某因子原始值做截面 z-score。"""
    keys = list(values.keys())
    arr = np.array([values[k] for k in keys], dtype=float)
    mu, sigma = arr.mean(), arr.std()
    if sigma < 1e-12:
        z = np.zeros_like(arr)
    else:
        z = (arr - mu) / sigma
    return {k: float(z[i]) for i, k in enumerate(keys)}


def rebalance_dates(start: str, end: str) -> list:
    """返回区间内的月末交易日（作为再平衡时点）。"""
    cal = pd.bdate_range(start, end)
    month_ends = cal.to_series().groupby(cal.to_period("M")).tail(1)
    return list(month_ends.index)
