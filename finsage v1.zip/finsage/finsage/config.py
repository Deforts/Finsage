"""全局配置：因子定义、LLM 接入、数据源、路径。

LLM 接入说明（呼应需求文档第 5/6 节）：
- 采用 OpenAI 兼容接口，支持通义千问 / 智谱 GLM 一键切换。
- 读取环境变量中的 API Key；若未配置，则所有 LLM 调用自动降级为
  确定性 Mock（各 Agent 自带 fallback），保证系统离线可跑、演示稳定。
- 配置好 Key 后无需改代码，自动切到真实大模型。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

# ----------------------------------------------------------------------------
# 路径
# ----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent          # .../finsage/finsage
PKG_ROOT = BASE_DIR.parent                            # .../finsage
DATA_DIR = PKG_ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR = DATA_DIR / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR = DATA_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------------------------------
# 因子定义（规模/价值/动量/波动率/质量 五类风格因子）
# ----------------------------------------------------------------------------
FACTOR_NAMES: List[str] = ["size", "value", "momentum", "volatility", "quality"]
FACTOR_CN = {
    "size": "规模",
    "value": "价值",
    "momentum": "动量",
    "volatility": "波动率",
    "quality": "质量",
}
# 因子方向：1 表示值越大越优（已标准化后），-1 表示值越小越优
FACTOR_DIRECTION = {
    "size": 1,        # 小盘溢价视角：此处按原始市值标准化，方向在评分时由方向系数决定
    "value": 1,       # 价值：估值越低(EP越高)越优
    "momentum": 1,    # 动量：过去收益越高越优
    "volatility": -1, # 波动率：越低越优
    "quality": 1,     # 质量：ROE/盈利越优
}

# 默认股票池（沪深 300 样例，演示用；可在 CLI 覆盖）
DEFAULT_POOL = [
    "600519.SH",  # 贵州茅台
    "601318.SH",  # 中国平安
    "600036.SH",  # 招商银行
    "000858.SZ",  # 五粮液
    "601012.SH",  # 隆基绿能
    "000333.SZ",  # 美的集团
    "600276.SH",  # 恒瑞医药
    "002594.SZ",  # 比亚迪
    "601888.SH",  # 中国中免
    "600900.SH",  # 长江电力
]

# 静态等权基准权重
STATIC_WEIGHTS = {f: 1.0 / len(FACTOR_NAMES) for f in FACTOR_NAMES}


# ----------------------------------------------------------------------------
# LLM 配置（OpenAI 兼容）
# ----------------------------------------------------------------------------
def _load_dotenv() -> None:
    """轻量加载项目根目录 .env（不依赖 python-dotenv），仅补充未设置的环境变量。"""
    env_path = PKG_ROOT / ".env"
    if not env_path.exists():
        return
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip().strip('"').strip("'")
            os.environ.setdefault(k, v)


def _detect_llm() -> dict:
    """按环境变量自动识别 LLM 提供方与 Key（会先尝试加载 .env）。"""
    _load_dotenv()
    # 通义千问 DashScope
    qwen_key = os.getenv("DASHSCOPE_API_KEY") or os.getenv("QWEN_API_KEY")
    if qwen_key:
        return {
            "provider": "qwen",
            "api_key": qwen_key,
            "base_url": os.getenv(
                "DASHSCOPE_BASE_URL",
                "https://dashscope.aliyuncs.com/compatible-mode/v1",
            ),
            "model": os.getenv("DASHSCOPE_MODEL", "qwen-plus"),
        }
    # 智谱 GLM
    glm_key = os.getenv("ZHIPU_API_KEY") or os.getenv("GLM_API_KEY")
    if glm_key:
        return {
            "provider": "glm",
            "api_key": glm_key,
            "base_url": os.getenv(
                "ZHIPU_BASE_URL",
                "https://open.bigmodel.cn/api/paas/v4",
            ),
            "model": os.getenv("ZHIPU_MODEL", "glm-4-plus"),
        }
    # 通用 OpenAI 兼容（含本地 vLLM / Ollama 等）
    oai_key = os.getenv("OPENAI_API_KEY")
    if oai_key:
        return {
            "provider": "openai",
            "api_key": oai_key,
            "base_url": os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
            "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        }
    return {"provider": "mock", "api_key": "", "base_url": "", "model": "mock"}


@dataclass
class LLMConfig:
    provider: str = "mock"
    api_key: str = ""
    base_url: str = ""
    model: str = "mock"
    temperature: float = 0.3
    timeout: int = 40
    max_tokens: int = 1500
    # 无 Key 时是否降级 Mock（默认 True，保证可跑）
    mock_fallback: bool = True
    # 运行时强制覆盖 enabled（如 demo 切换"离线 Mock"），None 表示按 api_key 推导
    _enabled_override: Optional[bool] = None

    @classmethod
    def from_env(cls) -> "LLMConfig":
        d = _detect_llm()
        return cls(**d)

    @property
    def enabled(self) -> bool:
        if self._enabled_override is not None:
            return self._enabled_override
        return bool(self.api_key)

    @enabled.setter
    def enabled(self, v: Optional[bool]) -> None:
        self._enabled_override = v


# ----------------------------------------------------------------------------
# 数据配置
# ----------------------------------------------------------------------------
@dataclass
class DataConfig:
    source: str = "akshare"          # akshare | synthetic
    pool: List[str] = field(default_factory=lambda: list(DEFAULT_POOL))
    start: str = "2025-01-01"
    end: str = "2025-12-31"
    # 情绪/舆情抓取来源（演示量）
    news_limit: int = 20


# ----------------------------------------------------------------------------
# 全局聚合配置
# ----------------------------------------------------------------------------
@dataclass
class AppConfig:
    llm: LLMConfig = field(default_factory=LLMConfig.from_env)
    data: DataConfig = field(default_factory=DataConfig)
    top_n: int = 5                   # 组合持仓 Top-N
    rebalance: str = "M"            # 再平衡频率：M=月
    seed: int = 42


CONFIG = AppConfig()
