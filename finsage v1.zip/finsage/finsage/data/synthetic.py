"""合成样本数据生成（Akshare 不可用时的兜底）。

保证任何环境下 FinSage 都能跑通端到端演示：
- 价格：带漂移/波动的几何随机游走，叠加温和的"牛熊"regime。
- 基本面：市值/PE/PB/ROE 在合理区间内采样。
- 舆情：带情绪倾向的新闻标题模板（供 SentimentAgent 使用）。
"""

from __future__ import annotations

import hashlib
import numpy as np
import pandas as pd

_POS = [
    "{name}发布半年报，营收与净利双双超预期，机构上调评级",
    "{name}中标重大订单，金额创近年新高，产能利用率饱满",
    "{name}宣布回购计划，管理层称当前估值具备长期配置价值",
    "行业景气度回升，{name}作为龙头率先受益，北向资金连续净流入",
    "{name}新产品获批，市场看好其第二增长曲线",
]
_NEG = [
    "{name}遭机构大宗折价减持，短期筹码承压",
    "{name}下修业绩预告，毛利率不及预期引发担忧",
    "行业监管趋严，{name}所在赛道估值面临重估压力",
    "{name}主要客户订单延后，全年指引下调",
    "舆情发酵：{name}被曝环保整改，市场情绪偏谨慎",
]
_NEU = [
    "{name}召开临时股东大会，议案获通过",
    "{name}发布日常经营公告，无重大变化",
    "分析师关注{name}后续催化，维持中性看法",
]


def _seed_for(stock: str, salt: int = 0) -> np.random.Generator:
    h = int(hashlib.sha256((stock + str(salt)).encode()).hexdigest(), 16)
    return np.random.default_rng(h & 0xFFFFFFFF)


def _trading_days(start: str, end: str) -> pd.DatetimeIndex:
    return pd.bdate_range(start, end)


def make_stock(stock: str, start: str, end: str, seed: int = 42):
    """因子优先的生成器：先造带 regime 依赖的因子→收益信号，再反推价格。

    目的：让 LSTM-Attention / 动态权重真正"有信号可学"，演示"动态配置优于
    静态等权"。两种市场状态（regime）：
      - 动量 regime（前 60%）：下期收益主要由动量(+质量)驱动；
      - 防御 regime（后 40%）：下期收益主要由低波动(+质量)驱动，
        且低波动个股真实呈现更低已实现波动。
    """
    rng = _seed_for(stock, seed)
    days = _trading_days(start, end)
    n = len(days)

    # 因子潜在序列（AR(1)），先标准化
    def ar1(rho, sig):
        x = np.zeros(n)
        x[0] = rng.normal(0, sig)
        for t in range(1, n):
            x[t] = rho * x[t - 1] + rng.normal(0, sig)
        return (x - x.mean()) / (x.std() + 1e-9)

    mom_n = ar1(0.92, 0.03)
    lowvol_n = ar1(0.92, 0.03)
    qual_n = ar1(0.92, 0.03)
    val_n = ar1(0.92, 0.03)

    split = int(0.6 * n)
    r = np.zeros(n)
    for t in range(1, n):
        if t < split:  # 动量 regime
            s = 0.7 * mom_n[t - 1] + 0.2 * qual_n[t - 1] + 0.1 * val_n[t - 1]
        else:          # 防御 regime
            s = 0.7 * lowvol_n[t - 1] + 0.3 * qual_n[t - 1]
        # 低波动个股真实更低波动：噪声标准差随 lowvol_n 反向变动
        noise_std = 0.011 * float(np.clip(1 - 0.6 * lowvol_n[t - 1], 0.35, 1.6))
        r[t] = 0.0004 + 0.0045 * s + rng.normal(0, noise_std)

    price = 25.0 * np.cumprod(1 + r)
    price = np.maximum(price, 1.0)

    op = price * (1 + rng.normal(0, 0.003, n))
    hi = np.maximum(op, price) * (1 + np.abs(rng.normal(0, 0.004, n)))
    lo = np.minimum(op, price) * (1 - np.abs(rng.normal(0, 0.004, n)))
    vol = rng.integers(8_000_000, 60_000_000, n).astype(float)
    amt = vol * price

    prices = pd.DataFrame(
        {
            "open": op,
            "high": hi,
            "low": lo,
            "close": price,
            "volume": vol,
            "amount": amt,
        },
        index=days,
    )
    prices.index.name = "date"

    market_cap = float(price[-1] * rng.integers(1_000_000_000, 2_000_000_000_000))
    pe = float(rng.uniform(8, 45))
    pb = float(rng.uniform(0.8, 8.0))
    roe = float(rng.uniform(0.05, 0.25))

    # 新闻：按日期撒点，带情绪倾向
    n_news = rng.integers(4, 10)
    idx = rng.choice(n, size=n_news, replace=False)
    name = stock.split(".")[0]
    news = []
    for i in idx:
        roll = rng.random()
        if roll < 0.45:
            tpl, lean = rng.choice(_POS), 1
        elif roll < 0.75:
            tpl, lean = rng.choice(_NEG), -1
        else:
            tpl, lean = rng.choice(_NEU), 0
        d = days[i]
        news.append(
            {
                "date": d.strftime("%Y-%m-%d"),
                "title": tpl.format(name=name),
                "content": tpl.format(name=name)
                + "（本条为演示合成文本，不代表真实事件）",
                "source": "合成舆情",
                "lean": int(lean),
            }
        )
    news.sort(key=lambda x: x["date"])

    return prices, {"market_cap": market_cap, "pe": pe, "pb": pb, "roe": roe}, news
