"""数据 Provider：优先 Akshare 真实拉取，失败/离线回退合成数据。

对外统一接口：load(pool, start, end) -> dict[code, StockData]。
每个 StockData 内部一致（要么全真实、要么全合成），避免因子口径错位。
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from .synthetic import make_stock


def _code_to_ak(code: str) -> str:
    """600519.SH -> 600519"""
    return code.split(".")[0]


@dataclass
class StockData:
    code: str
    prices: pd.DataFrame                # index=date, cols=[open,high,low,close,volume,amount]
    fundamentals: dict                  # market_cap, pe, pb, roe
    news: List[dict] = field(default_factory=list)
    synthetic: bool = False


class DataProvider:
    def __init__(
        self,
        source: str = "akshare",
        news_limit: int = 20,
        warmup_days: int = 120,
        timeout: float = 25.0,
    ):
        self.source = source
        self.news_limit = news_limit
        self.warmup_days = warmup_days
        self.timeout = timeout

    def load(self, pool: List[str], start: str, end: str) -> Dict[str, StockData]:
        # 提前 warmup，给因子计算留出回看窗口
        warm_start = (
            pd.Timestamp(start) - pd.Timedelta(days=self.warmup_days)
        ).strftime("%Y-%m-%d")
        out: Dict[str, StockData] = {}
        for code in pool:
            out[code] = self._load_one(code, warm_start, end)
        return out

    # ---- 单只 ----------------------------------------------------------
    def _load_one(self, code: str, start: str, end: str) -> StockData:
        if self.source == "synthetic":
            return self._synthetic(code, start, end)
        try:
            return self._akshare(code, start, end)
        except Exception as e:  # noqa: BLE001
            return self._synthetic(code, start, end, reason=str(e))

    # ---- 合成 ----------------------------------------------------------
    def _synthetic(self, code: str, start: str, end: str, reason: str = "") -> StockData:
        prices, fund, news = make_stock(code, start, end, seed=42)
        return StockData(
            code=code, prices=prices, fundamentals=fund, news=news, synthetic=True
        )

    # ---- Akshare -------------------------------------------------------
    # 注意：沙箱/公司内网环境通常**必须**经本地代理出网（直连会被拒），
    # 但代理对数据源时通时断 → 用「失败重试」而非「禁用代理」来对抗抖动。
    def _akshare(self, code: str, start: str, end: str) -> StockData:
        import akshare as ak
        import time as _time

        sym = _code_to_ak(code)
        sd = pd.Timestamp(start).strftime("%Y%m%d")
        ed = pd.Timestamp(end).strftime("%Y%m%d")

        # 行情：重试 3 次（代理抖动 → 间歇性 ProxyError/RemoteDisconnected）
        raw = None
        last_err: Exception | None = None
        for attempt in range(3):
            try:
                raw = ak.stock_zh_a_hist(
                    symbol=sym, period="daily", start_date=sd, end_date=ed,
                    adjust="qfq",
                )
                break
            except Exception as e:  # noqa: BLE001
                last_err = e
                if attempt < 2:
                    _time.sleep(1.5 * (attempt + 1))
        if raw is None:
            raise last_err  # noqa: TRY201

        # 行情
        raw = ak.stock_zh_a_hist(
            symbol=sym, period="daily", start_date=sd, end_date=ed, adjust="qfq"
        )
        raw = raw.rename(
            columns={
                "日期": "date", "开盘": "open", "最高": "high",
                "最低": "low", "收盘": "close", "成交量": "volume", "成交额": "amount",
            }
        )
        raw["date"] = pd.to_datetime(raw["date"])
        prices = raw.set_index("date")[
            ["open", "high", "low", "close", "volume", "amount"]
        ].astype(float)
        if prices.empty:
            raise ValueError("empty price")

        # 估值/市值
        fund = {"market_cap": float(prices["close"].iloc[-1] * 1e9), "pe": 15.0, "pb": 2.0, "roe": 0.12}
        try:
            ind = ak.stock_a_indicator_lg(symbol=sym)
            if ind is not None and not ind.empty:
                last = ind.iloc[-1]
                fund["pe"] = float(last.get("市盈率(TTM)", fund["pe"]) or fund["pe"])
                fund["pb"] = float(last.get("市净率", fund["pb"]) or fund["pb"])
                fund["market_cap"] = float(last.get("市值", fund["market_cap"]) or fund["market_cap"])
        except Exception:
            pass

        # 新闻/舆情
        news = []
        try:
            nw = ak.stock_news_em(symbol=sym)
            nw = nw.rename(columns={"新闻标题": "title", "新闻内容": "content",
                                     "发布时间": "date", "文章来源": "source"})
            for _, r in nw.head(self.news_limit).iterrows():
                news.append({
                    "date": str(r.get("date", ""))[:10],
                    "title": str(r.get("title", "")),
                    "content": str(r.get("content", "")),
                    "source": str(r.get("source", "东方财富")),
                    "lean": 0,
                })
        except Exception:
            pass

        return StockData(code=code, prices=prices, fundamentals=fund, news=news, synthetic=False)


def load_market(pool, start, end, source="akshare", news_limit=20) -> Dict[str, StockData]:
    return DataProvider(source=source, news_limit=news_limit).load(pool, start, end)
