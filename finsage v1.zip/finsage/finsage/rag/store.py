"""轻量向量库（RAG）：TF-IDF + 余弦相似，零重依赖。

作为 Chroma/FAISS 的兜底实现——接口一致，后续可无缝替换为
`chromadb` 而不改动调用方。用于存储因子说明文档、新闻原文、
历史报告，供检索增强报告生成。
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Doc:
    id: str
    text: str
    meta: dict = field(default_factory=dict)


def _tokenize(text: str) -> List[str]:
    # 中文按字、英文按词，统一小写
    text = text.lower()
    toks = re.findall(r"[a-z0-9]+|[一-鿿]", text)
    return toks


class VectorStore:
    def __init__(self):
        self.docs: Dict[str, Doc] = {}
        self._df: Dict[str, int] = {}
        self._idf: Dict[str, float] = {}
        self._vecs: Dict[str, Dict[str, float]] = {}
        self._N = 0

    def ingest(self, docs: List[Doc]):
        for d in docs:
            self.docs[d.id] = d
        self._build()

    def _build(self):
        self._N = len(self.docs)
        self._df = {}
        raw = {}
        for did, d in self.docs.items():
            toks = _tokenize(d.text)
            tf = {}
            for t in toks:
                tf[t] = tf.get(t, 0) + 1
            raw[did] = tf
            for t in tf:
                self._df[t] = self._df.get(t, 0) + 1
        self._idf = {
            t: math.log((self._N + 1) / (df + 1)) + 1
            for t, df in self._df.items()
        }
        self._vecs = {}
        for did, tf in raw.items():
            vec = {}
            norm = 0.0
            for t, c in tf.items():
                w = (1 + math.log(c)) * self._idf.get(t, 1)
                vec[t] = w
                norm += w * w
            norm = math.sqrt(norm) or 1.0
            self._vecs[did] = {t: w / norm for t, w in vec.items()}

    def search(self, query: str, k: int = 3) -> List[Doc]:
        q = {}
        norm = 0.0
        for t in _tokenize(query):
            q[t] = q.get(t, 0) + 1
            norm += 1
        norm = math.sqrt(norm) or 1.0
        qv = {t: (1 + math.log(c)) * self._idf.get(t, 1) / norm for t, c in q.items()}
        scored = []
        for did, vec in self._vecs.items():
            dot = sum(w * vec.get(t, 0.0) for t, w in qv.items())
            scored.append((dot, did))
        scored.sort(reverse=True)
        return [self.docs[did] for _, did in scored[:k]]
