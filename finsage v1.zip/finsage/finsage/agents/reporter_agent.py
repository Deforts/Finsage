"""ReporterAgent：汇总所有上游输出，生成结构化自然语言投研报告。

报告结构：市场概述 → 个股逻辑 → 因子贡献 → 风险提示。
所有结论须有上游 Agent 输出支撑；文末强制附"不构成投资建议"声明。
"""

from __future__ import annotations

import datetime as _dt

from .. import DISCLAIMER
from ..config import FACTOR_CN, FACTOR_NAMES
from .base import BaseAgent


class ReporterAgent(BaseAgent):
    name = "ReporterAgent"
    role = "报告生成专家：汇总各 Agent 输出为结构化投研报告"

    def __init__(self, llm=None):
        super().__init__(llm)

    def run(self, state: dict) -> dict:
        md = self._render(state)
        state["report"] = md
        state["advice"] = self._build_advice(state)
        return state

    # ------------------------------------------------------------------
    @staticmethod
    def _horizon_text(rebs) -> str:
        """根据最近两次调仓日估算持有期（下一个调仓周期长度）。"""
        if not rebs or len(rebs) < 2:
            return "至下一调仓日"
        try:
            d0 = _dt.date.fromisoformat(str(rebs[-2])[:10])
            d1 = _dt.date.fromisoformat(str(rebs[-1])[:10])
            gap = max((d1 - d0).days, 1)
            return f"约 {gap} 天（至下一调仓日）"
        except Exception:  # noqa: BLE001
            return "至下一调仓日"

    def _build_advice(self, state: dict) -> list:
        """生成可执行的组合建议：动作 / 建议仓位 / 依据 / 持有期。

        动作规则：
        - 综合得分进入 Top-N  → 买入（BUY），等权分配仓位
        - 未进 Top-N 且情绪明显偏负（<-0.3）→ 减持（REDUCE）
        - 其余 → 持有观察（HOLD）
        - 命中个股级风控且原为买入 → 降为谨慎买入，仓位减半
        """
        research = state.get("research", {})
        ranking = research.get("ranking", [])
        if not ranking:
            return []
        top_n = int(state.get("top_n", 5) or 5)
        sent_panel = state.get("sentiment_panel") or []
        sent_last = sent_panel[-1]["sentiment"] if sent_panel else {}
        risk_list = (state.get("risks") or {}).get("list", []) or []
        horizon = self._horizon_text(state.get("rebalance_dates"))
        n = len(ranking)
        # 关键：Top-N 不能超过股票池只数，否则按 1/N 分配会导致
        # 合计仓位 < 100%（例：池子 3 只、N=10 → 每只 10%，合计仅 30%）。
        # 因此以实际排名池大小为上限做钳制，保证买入标的等权合计 = 100%。
        eff_n = max(min(top_n, n), 1)

        out = []
        for i, r in enumerate(ranking):
            code = r["stock"]
            score = float(r.get("score", 0.0))
            ss = float(sent_last.get(code, {}).get("score", 0.0))

            if i < eff_n:
                action, pos = "买入 BUY", 1.0 / eff_n
                reason = f"综合得分第 {i+1}/{n}（{score:.2f}），进入 Top-{eff_n} 持仓池"
            elif ss < -0.3:
                action, pos = "减持 REDUCE", 0.0
                reason = f"未进 Top-{eff_n} 且舆情偏负面（{ss:+.2f}）"
            else:
                action, pos = "持有观察 HOLD", 0.0
                reason = f"综合得分第 {i+1}/{n}（{score:.2f}），暂不调整"

            if ss <= -0.3 and action.startswith("买入"):
                reason += f"；情绪偏冷（{ss:+.2f}）"

            # 个股级风控命中 → 买入降级为谨慎买入（仓位减半）
            hit = [x for x in risk_list if code in str(x)]
            if hit and action.startswith("买入"):
                action, pos = "谨慎买入 BUY（减半）", pos / 2
                reason += f"；触发风控：{str(hit[0])[:40]}"

            out.append({
                "rank": i + 1, "code": code, "score": score,
                "sentiment": ss, "action": action, "position": pos,
                "reason": reason, "horizon": horizon,
            })
        return out

    # ------------------------------------------------------------------
    def _gen_conclusion(self, state: dict) -> str:
        """调用 LLM 生成 3-5 段投研结论（市场风格/因子逻辑/回测/展望）。"""
        research = state["research"]
        bt = state["backtest"]
        ranking = research["ranking"]
        dyn = research["dynamic_weights"]
        top = ranking[0]
        top_factor = max(dyn, key=dyn.get)
        # 因子权重排序（高→低）
        ranked = sorted(dyn.items(), key=lambda x: -x[1])
        top2_factor = ranked[1][0]
        factor_lines = "、".join(f"{FACTOR_CN[f]}{dyn[f]:.0%}" for f, _ in ranked)
        dyn_r = bt["dynamic"]["total_return"]
        sta_r = bt["static_equalweight"]["total_return"]
        excess = dyn_r - sta_r

        prompt = (
            "你是一位资深量化投研分析师。基于以下量化结果，写 3-5 段连续分析（每段用空行分隔）。\n"
            "要求：\n"
            "1. 不使用 markdown 标题、不列点，只输出连续中文段落\n"
            "2. 第一段：当前市场风格判断（结合最高权重因子）\n"
            "3. 第二段：因子选择的内在逻辑（解释为什么得分 Top 标的能进组合）\n"
            "4. 第三段：动态权重 vs 静态等权的回测对比解读（必须含具体超额、夏普、回撤）\n"
            "5. 第四段：下期展望与关注点（因子钝化、舆情、仓位三方面）\n"
            "6. 全部基于给定数据，不得编造数字，不得引用未提供的信息\n\n"
            f"【因子动态权重排序】{factor_lines}\n"
            f"【权重 Top1】{FACTOR_CN[top_factor]}（{dyn[top_factor]:.0%}）"
            f"【Top2】{FACTOR_CN[top2_factor]}（{dyn[top2_factor]:.0%}）\n"
            f"【综合得分第一标的】{top['stock']}（得分 {top['score']:.2f}）\n"
            f"【回测】动态 {dyn_r:.1%}，静态等权 {sta_r:.1%}，超额 {excess:+.1%}；"
            f"动态夏普 {bt['dynamic']['sharpe']:.2f}，静态夏普 {bt['static_equalweight']['sharpe']:.2f}；"
            f"动态最大回撤 {bt['dynamic']['max_drawdown']:.1%}，静态最大回撤 {bt['static_equalweight']['max_drawdown']:.1%}。"
        )
        sys = "你是资深量化投研分析师，输出专业、克制、有依据、不编造数字。"
        fallback_text = (
            f"本期市场风格以{FACTOR_CN[top_factor]}为锚（权重 {dyn[top_factor]:.0%}），"
            f"辅以{FACTOR_CN[top2_factor]}（{dyn[top2_factor]:.0%}）形成本期因子敞口。"
            f"模型在因子通道融合个股舆情后，输出综合得分首位为 {top['stock']}（{top['score']:.2f}），"
            f"该标的多因子截面上的相对优势支撑了排序结果。\n\n"
            f"回测显示动态权重策略累计收益 {dyn_r:.1%}，较静态等权基准超额 {excess:+.1%}，"
            f"夏普 {bt['dynamic']['sharpe']:.2f}、最大回撤 {bt['dynamic']['max_drawdown']:.1%}；"
            f"区间内的状态切换（regime）由因子 IC 驱动，避免了单一因子的样本内过拟合。\n\n"
            f"下期关注：一是{FACTOR_CN[top_factor]}因子在末段是否出现钝化迹象，"
            f"若单因子 IC 在最近 3 期持续为负则权重进入衰减通道；"
            f"二是舆情通道对极端负向事件（情绪分 < -0.5）的反应是否充分；"
            f"三是组合回撤预警线（-10%）附近的现金留存与再配置节奏。"
        )
        try:
            if not self.llm.available:
                return fallback_text
            # 推理模型（如 glm-5.3-flash）reasoning 占用预算，1500 够 3-5 段中文
            text = self.llm.complete(sys, prompt, max_tokens=1500, temperature=0.4).strip()
            if not text:
                # 推理模型偶发 content 为空（token 全被 reasoning 吃光）→ 仍走兜底
                return fallback_text
            return text
        except Exception:
            return fallback_text

    # ------------------------------------------------------------------
    def _gen_methodology(self) -> str:
        """因子配置方法论综述（基于学术经典文献，硬编码保证稳定与可核实）。"""
        return (
            "本系统的因子配置方法承自多因子定价文献脉络，下面梳理与本系统直接相关的"
            "几个关键节点，以便读者理解因子选择与组合构建的理论依据。\n\n"
            "**多因子定价的实证基础：** Fama & French (1993) 提出的三因子模型"
            "（市场、规模 SMB、价值 HML）奠定了多因子解释横截面收益的基础；"
            "Fama & French (2015) 进一步加入盈利能力（RMW）与投资风格（CMA）"
            "构成五因子模型。Carhart (1997) 在此基础上加入动量因子（MOM）形成四因子模型，"
            "Piotroski (2000) 的 F-Score 进一步把质量因子细化为可量化的多维评分。"
            "本系统的五类风格因子——规模、价值、动量、波动率、质量——"
            "可视为上述文献的工程化精简版：\n\n"
            "- **规模因子**：以 -log(市值) 代理，对应 SMB；\n"
            "- **价值因子**：以 1/PE（盈利收益率 EP，随价格动态）代理，对应 HML；\n"
            "- **动量因子**：过去若干交易日累计收益（跳过近 5 日避免反转），对应 MOM；\n"
            "- **波动率因子**：近 20 日收益标准差，越低越优，对应 Ang et al. (2006) 的"
            "'低波动率异象'（低波动组合长期跑赢高波动组合的反直觉结论）；\n"
            "- **质量因子**：以 ROE 度量盈利质量，对应 Sloan (1996) 的盈余持续性研究。\n\n"
            "**动态因子配置的研究演进：** Asness et al. (2000) 发现价值/动量在跨期"
            "存在反向关系，是因子轮动研究的起点。Hou et al. (2017) 的 q-factor 模型"
            "强调投资因子对截面收益的解释力。近年随着深度学习在金融领域的渗透，"
            "Fischer & Krauss (2018) 用 LSTM 对 S&P 500 成分股做排序、"
            "Gu et al. (2020) 用图神经网络做资产定价，均取得较传统线性模型更好的样本外表现。\n\n"
            "**与静态等权基准的对比意义：** 静态等权（等权配置各风格因子）"
            "是因子组合研究的经典基准（DeMiguel et al., 2009），但其隐含假设是"
            "各因子在不同时点具有稳定的预测能力，这与实证中常见的因子轮动现象相悖。"
            "本系统的动态权重在 regime 切换时倾斜方向——"
            "动量扩张期增配趋势类因子，防御期增配低波动与质量因子——"
            "目标是提高组合在不同市场环境下的稳健性。本期回测亦观察到了"
            "动态权重组合相对静态等权基准的超额收益迹象，"
            "但需注意样本期与样本内/外选择对该结论稳健性的影响。"
        )

    # ------------------------------------------------------------------
    def _render(self, state: dict) -> str:
        pool = state["pool"]
        start, end = state["start"], state["end"]
        research = state["research"]
        risks = state["risks"]
        bt = state["backtest"]
        last_panel = state["factor_panel"][-1]
        last_factors = last_panel["factors"]
        sent_last = state["sentiment_panel"][-1]["sentiment"]
        synth = state.get("_factor_synthetic", False)
        synth_map = state.get("_synthetic_map", {})
        n_fb = sum(1 for v in synth_map.values() if v)
        if synth:
            src = "合成样本数据（Akshare 不可用时的兜底）"
        elif n_fb:
            src = (f"Akshare 真实数据 · ⚠️ {n_fb}/{len(synth_map)} 只拉取失败"
                   f"已回退合成，相关标的的结论不可作为真实依据")
        else:
            src = "Akshare 真实数据"
        engine = "双通道 LSTM-Attention 融合模型" if research["used_torch"] else "因子 IC + regime 启发式"

        out = []
        out.append(f"# FinSage 投研决策报告\n")
        out.append(f"> 区间：{start} ~ {end}　|　股票池：{len(pool)} 只　|　数据源：{src}　|　引擎：{engine}\n")

        # 1. 市场概述
        out.append("## 一、市场概述\n")
        out.append(
            f"本系统对股票池 {len(pool)} 只标的，在 {start} 至 {end} 区间内，"
            f"融合五类风格因子（规模/价值/动量/波动率/质量）与个股舆情，"
            f"由 {engine} 生成动态因子权重并进行组合构建。\n"
        )

        # 1.5 因子配置方法论综述（参考文献基础）
        out.append("## 二、因子配置方法论综述（参考文献）\n")
        out.append(self._gen_methodology())
        out.append("")

        # 2. 个股逻辑（Top-N）
        out.append("## 三、个股逻辑（综合得分排名）\n")
        out.append("| 排名 | 标的 | 综合得分 | 规模 | 价值 | 动量 | 波动率 | 质量 | 情绪分 |")
        out.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
        for i, r in enumerate(research["ranking"]):
            code = r["stock"]
            fv = last_factors.get(code, {})
            ss = sent_last.get(code, {}).get("score", 0.0)
            out.append(
                f"| {i+1} | {code} | {r['score']:.3f} | "
                f"{fv.get('size',0):.2f} | {fv.get('value',0):.2f} | {fv.get('momentum',0):.2f} | "
                f"{fv.get('volatility',0):.2f} | {fv.get('quality',0):.2f} | {ss:+.2f} |"
            )
        out.append("")

        # 3. 因子贡献（动态权重 + 推理链）
        out.append("## 四、因子贡献与动态权重\n")
        out.append("**本期动态因子权重：**\n")
        out.append("| 因子 | 权重 |")
        out.append("| --- | --- |")
        for f in FACTOR_NAMES:
            out.append(f"| {FACTOR_CN[f]} | {research['dynamic_weights'][f]:.1%} |")
        out.append("")
        out.append("**推理链（可解释性）：**\n")
        out.append(research["rationale"])
        out.append("")

        # 3.5 因子说明（RAG 检索增强）
        rag_ctx = state.get("rag_context") or []
        if rag_ctx:
            out.append("**因子说明（RAG 检索增强）：**\n")
            for c in rag_ctx:
                out.append(f"- {c}")
            out.append("")

        # 3.6 智能投研结论（LLM 生成）
        out.append("## 五、智能投研结论（LLM 生成）\n")
        out.append(self._gen_conclusion(state))
        out.append("")

        # 3.7 组合建议（可执行决策）
        advice = self._build_advice(state)
        if advice:
            hold_txt = advice[0]["horizon"]
            n_buy = sum(1 for a in advice if a["position"] > 0)
            out.append("## 六、组合建议（可执行决策）\n")
            out.append(
                f"基于综合得分分位、个股舆情与风控命中情况，给出如下可执行建议。"
                f"建议持有期：**{hold_txt}**；"
                f"买入标的共 {n_buy} 只，按 **Top-{n_buy} 等权**分配仓位"
                f"（每只约 {1.0/max(n_buy,1):.1%}）。\n"
            )
            out.append("| 排名 | 标的 | 综合得分 | 情绪分 | 动作 | 建议仓位 | 依据 |")
            out.append("| --- | --- | --- | --- | --- | --- | --- |")
            for a in advice:
                pos_txt = f"{a['position']:.1%}" if a["position"] > 0 else "—"
                out.append(
                    f"| {a['rank']} | {a['code']} | {a['score']:.3f} | {a['sentiment']:+.2f} | "
                    f"{a['action']} | {pos_txt} | {a['reason']} |"
                )
            out.append("")
            buys = [a for a in advice if a["position"] > 0]
            if buys:
                tot = sum(b["position"] for b in buys)
                line = (
                    "**组合构建：** " +
                    "、".join(f"{b['code']}（{b['position']:.1%}）" for b in buys) +
                    f"，合计仓位 **{tot:.0%}**，其余标的暂不配置（持有观察或减持）。"
                )
                # 风控降级会让实际仓位低于满仓，差额即为现金留存，需显式说明
                if tot < 0.999:
                    line += f"\n\n**现金留存 {1-tot:.0%}：** 部分买入标的因触发风控被降级为半仓，" \
                            "释放的资金本期不再补仓，转为现金等待风险缓解后再配置。"
                out.append(line + "\n")

        # 4. 回测对比
        out.append("## 七、回测对比：动态权重 vs 静态等权\n")
        out.append("| 策略 | 累计收益 | 年化 | 最大回撤 | 夏普 |")
        out.append("| --- | --- | --- | --- | --- |")
        for key, label in [
            ("dynamic", "动态因子权重"),
            ("static_equalweight", "静态等权因子"),
            ("equal_all", "全样本等权"),
        ]:
            m = bt[key]
            out.append(
                f"| {label} | {m['total_return']:.1%} | {m['ann_return']:.1%} | "
                f"{m['max_drawdown']:.1%} | {m['sharpe']:.2f} |"
            )
        out.append("")

        # 5. 投资展望与情景分析
        dyn_r = bt["dynamic"]["total_return"]
        sta_r = bt["static_equalweight"]["total_return"]
        excess = dyn_r - sta_r
        dyn_sharpe = bt["dynamic"]["sharpe"]
        dyn_mdd = bt["dynamic"]["max_drawdown"]
        out.append("## 八、投资展望与情景分析\n")
        out.append(
            f"**本期运行小结**：动态权重组合本期累计收益 {dyn_r:.1%}，"
            f"相对静态等权基准超额 {excess:+.1%}，夏普 {dyn_sharpe:.2f}、"
            f"最大回撤 {dyn_mdd:.1%}。在区间后段，模型对低波动率因子的相对增配"
            f"降低了组合对尾部行情的暴露；从调仓轨迹看，"
            f"regime 切换点附近模型会以「状态平滑」为目标渐变权重，"
            f"避免一次性大幅倾斜带来的切换成本与过拟合风险。\n\n"
            f"**下期情景判断与组合应对**：\n\n"
            f"**① 趋势延续情景（动量扩张延续）**：若市场维持当前风格倾向，"
            f"模型将进一步增配趋势相关因子（动量、规模），"
            f"组合权重预计向高得分个股倾斜；当出现连续两期动量钝化信号时，"
            f"动量权重将自动下调，转向质量与价值等防御属性。\n\n"
            f"**② 防御情景（市场回调）**：若波动率因子权重进入 top1 且组合回撤"
            f"超过 -8%，建议现金留存比例从 0% 提升至 10%–20%，"
            f"对冲方式为降低高波动个股的仓位、保留低波动与高 ROE 个股。\n\n"
            f"**③ 风格切换情景**：若最大权重因子单期变动超过 15 个百分点，"
            f"组合进入重新平衡窗口；本期调仓以「状态平滑」为目标，"
            f"不会一次性大幅倾斜，避免切换成本与过拟合风险。\n\n"
            f"**持续关注点**：① 因子 IC 的近期稳定性，"
            f"若单因子 IC 在最近 3 期持续为负，则其权重进入衰减通道；"
            f"② 舆情通道对极端负向事件（情绪分 < -0.5）的反应是否充分；"
            f"③ 回撤预警线（-10%）附近的现金留存与再配置节奏。"
        )
        out.append("")

        # 5. 风险提示
        out.append("## 九、风险提示\n")
        for r in risks["list"]:
            out.append(f"- {r}")
        out.append("")
        out.append(f"**风控小结：** {risks['summary']}\n")

        # 强制声明
        out.append("---\n")
        out.append(f"{DISCLAIMER}\n")
        return "\n".join(out)
