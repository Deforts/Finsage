"""FactorAgent：计算五类风格因子，输出截面标准化因子矩阵。

严格按因子定义计算；缺失值用截面均值填充；不做主观判断。
产出写入 state['factor_panel'] / ['factor_mat'] / ['period_ret_mat']。
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import FACTOR_NAMES
from ..factors import compute_factor_raw, rebalance_dates, zscore_series
from .base import BaseAgent


class FactorAgent(BaseAgent):
    name = "FactorAgent"
    role = "因子计算专家：计算规模/价值/动量/波动率/质量五类风格因子并标准化"
    system_prompt = (
        "你是量化因子工程师。只做确定性因子计算，严格按定义处理缺失值，"
        "不做任何主观判断或预测。"
    )

    def run(self, state: dict) -> dict:
        pool = state["pool"]
        start, end = state["start"], state["end"]
        market = state["market"]
        dates = rebalance_dates(start, end)

        raw_by_date: dict = {}
        for d in dates:
            raw: dict = {}
            for code in pool:
                sd = market[code]
                r = compute_factor_raw(sd.prices, sd.fundamentals, d)
                if r:
                    raw[code] = r
            # 截面 z-score（逐因子）
            z = {}
            for f in FACTOR_NAMES:
                vals = {c: raw[c][f] for c in raw if f in raw[c]}
                zz = zscore_series(vals)
                for c in zz:
                    z.setdefault(c, {})[f] = zz[c]
            raw_by_date[d] = z

        N = len(pool)
        K = len(dates)
        factor_mat = np.zeros((N, K, len(FACTOR_NAMES)))
        factor_panel = []
        for ki, d in enumerate(dates):
            row = {}
            for si, code in enumerate(pool):
                fv = raw_by_date[d].get(code, {f: 0.0 for f in FACTOR_NAMES})
                for fi, f in enumerate(FACTOR_NAMES):
                    factor_mat[si, ki, fi] = fv.get(f, 0.0)
                row[code] = fv
            factor_panel.append({"date": d.strftime("%Y-%m-%d"), "factors": row})

        # 相邻再平衡日之间的个股区间收益（用于回测/监督目标）
        period_ret_mat = np.zeros((N, max(K - 1, 0)))
        for si, code in enumerate(pool):
            closes = market[code].prices["close"]
            for ki in range(K - 1):
                c0 = closes.asof(pd.Timestamp(dates[ki]))
                c1 = closes.asof(pd.Timestamp(dates[ki + 1]))
                if c0 and c1 and not pd.isna(c0) and not pd.isna(c1) and c0 > 0:
                    period_ret_mat[si, ki] = c1 / c0 - 1.0

        state["factor_panel"] = factor_panel
        state["factor_mat"] = factor_mat
        state["period_ret_mat"] = period_ret_mat
        state["rebalance_dates"] = [d.strftime("%Y-%m-%d") for d in dates]
        state["_factor_synthetic"] = all(market[c].synthetic for c in pool)
        # 逐股记录真实/合成状态：部分回退时报告要如实提示（不能静默）
        state["_synthetic_map"] = {c: bool(market[c].synthetic) for c in pool}
        return state
