"""SentimentAgent：抓取新闻/公告文本，做情感打分与情绪聚合。

输入：股票池对应新闻文本；输出：{stock, date, sentiment_score[-1,1], confidence, evidence}。
基于事实打分，输出置信度与依据原文片段，避免无依据情绪断言。
优先级：真实 LLM（Key 可用）> 合成倾向词典兜底。
"""

from __future__ import annotations

import json
import re

import numpy as np

from ..factors import rebalance_dates
from .base import BaseAgent


class SentimentAgent(BaseAgent):
    name = "SentimentAgent"
    role = "舆情研判专家：对个股新闻/公告做情感打分与情绪聚合"
    system_prompt = (
        "你是金融舆情分析师。仅基于给定的新闻/公告文本对个股情绪打分，"
        "范围[-1,1]，并给出置信度与依据原文片段。禁止无依据的情绪断言。"
        "输出严格为 JSON：{\"sentiment_score\":float,\"confidence\":float,\"evidence\":str}。"
    )
    # 真实 LLM 调用上限：默认股票池×调仓日远超此数，超限改用词典兜底，
    # 既保留真实大模型研判痕迹，又避免触碰中转站限流。
    LLM_CAP = 12

    def __init__(self, llm=None):
        super().__init__(llm)
        self._llm_calls = 0

    def run(self, state: dict) -> dict:
        market = state["market"]
        dates = rebalance_dates(state["start"], state["end"])  # 与 FactorAgent 独立并行
        pool = state["pool"]

        sentiment_panel = []
        N = len(pool)
        K = len(dates)
        sent_mat = np.zeros((N, K, 1))
        self._llm_calls = 0

        for ki, d in enumerate(dates):
            as_of = d.strftime("%Y-%m-%d")  # 字符串比较，避免 Timestamp 与字符串混用
            row = {}
            for si, code in enumerate(pool):
                score, conf, ev = self._score(code, market[code].news, as_of)
                row[code] = {"score": float(score), "confidence": float(conf), "evidence": ev}
                sent_mat[si, ki, 0] = score
            sentiment_panel.append({"date": as_of, "sentiment": row})

        state["sentiment_panel"] = sentiment_panel
        state["sent_mat"] = sent_mat
        state["_sentiment_llm_used"] = self._llm_calls
        return state

    # ------------------------------------------------------------------
    def _score(self, code: str, news: list, as_of: str):
        window = [n for n in news if n.get("date", "") <= as_of][-10:]
        if not window:
            return 0.0, 0.3, f"{as_of} 窗口内无可用舆情数据"

        text = "\n".join(f"- {n.get('title','')}" for n in window)
        user = (
            f"股票代码 {code}。截至 {as_of} 的近阶段新闻：\n{text}\n\n"
            "请基于上述事实输出 JSON。"
        )

        def fallback():
            lean = np.mean([n.get("lean", 0) for n in window]) if window else 0.0
            return float(np.clip(lean, -1, 1)), 0.5, (
                f"窗口内 {len(window)} 条舆情（合成倾向均值 {lean:.2f}），"
                "未接入真实 LLM，采用词典倾向兜底"
            )

        # 超过调用上限后直接用兜底，避免触发中转站限流
        if self._llm_calls >= self.LLM_CAP:
            return fallback()
        self._llm_calls += 1
        out = self._llm(user, fallback)
        try:
            m = re.search(r"\{.*\}", out, re.DOTALL)
            obj = json.loads(m.group(0)) if m else json.loads(out)
            sc = float(np.clip(obj.get("sentiment_score", 0.0), -1, 1))
            cf = float(np.clip(obj.get("confidence", 0.5), 0, 1))
            ev = str(obj.get("evidence", text[:60]))
            return sc, cf, ev
        except Exception:
            return fallback()
