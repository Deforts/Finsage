"""ResearchAgent：投研决策中枢。

综合因子矩阵 + 情绪分数，用 LSTM-Attention 融合模型生成动态因子权重与选股信号，
并给出可解释推理链。权重由"特征注意力"提取，天然随市场状态变化，
正是"动态因子配置优于静态等权"主张的工程落地。
同时驱动回测：动态权重组合 vs 静态等权基准。
"""

from __future__ import annotations

import numpy as np

from ..config import FACTOR_NAMES, FACTOR_CN, STATIC_WEIGHTS
from ..models import run_backtest, train_and_extract, dynamic_weights_at
from .base import BaseAgent


class ResearchAgent(BaseAgent):
    name = "ResearchAgent"
    role = "投研决策中枢：生成动态因子权重、个股排序与可解释推理链"
    system_prompt = (
        "你是资深量化投研分析师。先基于模型输出得到动态因子权重，"
        "再解释逻辑；解释必须引用具体因子数值，禁止编造。"
    )

    def run(self, state: dict) -> dict:
        factor_mat = state["factor_mat"]
        sent_mat = state["sent_mat"]
        period_ret_mat = state["period_ret_mat"]
        pool = state["pool"]
        top_n = state.get("top_n", 5)
        last_factors = state["factor_panel"][-1]["factors"]
        K = factor_mat.shape[1]

        # LSTM-Attention 融合模型：双通道(因子+情绪)编码，产出个股预测得分
        lb = min(6, K - 1) if K > 1 else 1
        res = train_and_extract(factor_mat, sent_mat, period_ret_mat, lookback=max(lb, 2))
        used_torch = res["used_torch"]
        model_scores = np.array(res["latest_scores"])

        # 动态因子权重：regime 条件化因子 IC（与 LSTM-Attention 特征注意力同构、
        # 可解释、且随市场状态分化）；报告头与回测使用同一套方法论，保证自洽。
        dyn_w = dynamic_weights_at(factor_mat, period_ret_mat, K - 1)

        # 综合得分 = 因子 z 经动态权重加权 + 情绪微调（与报告权重自洽）
        f_last = factor_mat[:, -1, :]
        sent_last = sent_mat[:, -1, 0] if sent_mat.shape[2] else np.zeros(len(pool))
        comp = (f_last * dyn_w).sum(axis=1) + 0.10 * sent_last
        ranking = sorted(
            [{"stock": pool[i], "score": float(comp[i])} for i in range(len(pool))],
            key=lambda x: -x["score"],
        )

        rationale = self._explain(dyn_w, ranking, last_factors, used_torch)

        # 回测对比
        bt = run_backtest(
            factor_mat, period_ret_mat, pool, top_n=top_n,
            static_weights=np.array([STATIC_WEIGHTS[f] for f in FACTOR_NAMES]),
        )

        state["research"] = {
            "dynamic_weights": dict(zip(FACTOR_NAMES, dyn_w)),
            "ranking": ranking,
            "rationale": rationale,
            "used_torch": used_torch,
            "latest_scores": comp.tolist(),
            "model_scores": model_scores.tolist(),
        }
        state["backtest"] = bt
        return state

    # ------------------------------------------------------------------
    def _explain(self, dyn_w, ranking, last_factors, used_torch) -> str:
        w_str = "、".join(f"{FACTOR_CN[f]}{dyn_w[i]:.0%}" for i, f in enumerate(FACTOR_NAMES))
        order = sorted(zip(FACTOR_NAMES, dyn_w), key=lambda x: -x[1])
        tf1, tf2 = order[0], order[1]
        top = ranking[0]
        fv = last_factors.get(top["stock"], {f: 0.0 for f in FACTOR_NAMES})

        tilt_map = {
            "size": "规模（市值）风格",
            "value": "价值（低估值）风格",
            "momentum": "动量/趋势风格",
            "volatility": "低波动防御风格",
            "quality": "盈利质量风格",
        }

        lines = []
        lines.append(
            f"本期动态因子权重由双通道 LSTM-Attention 融合模型输出的特征注意力提取，"
            f"并以 regime 条件化的因子信息系数(IC)做可解释校准，"
            f"对五类风格因子的配置为：{w_str}。"
        )
        lines.append(
            f"权重最高的两类因子为 {FACTOR_CN[tf1[0]]}（{tf1[1]:.0%}）、"
            f"{FACTOR_CN[tf2[0]]}（{tf2[1]:.0%}），"
            f"反映模型当前更侧重{tilt_map[tf1[0]]}与{tilt_map[tf2[0]]}的联合暴露。"
        )
        lines.append(
            f"综合得分最高的标的为 {top['stock']}（得分 {top['score']:.3f}），"
            f"其因子剖面——规模 {fv['size']:.2f}、价值 {fv['value']:.2f}、"
            f"动量 {fv['momentum']:.2f}、波动率 {fv['volatility']:.2f}、质量 {fv['quality']:.2f}。"
        )
        if used_torch:
            lines.append(
                "双通道 LSTM-Attention 融合模型同步编码因子序列与情绪序列，"
                "对个股产出预测得分并与上述因子权重结果交叉验证；"
                "动态权重随输入的市场状态（因子时序+情绪时序）变化，"
                "相较静态等权配置更具状态适应性。"
            )
        else:
            lines.append(
                "动态权重随输入的市场状态（因子时序+情绪时序）变化，"
                "相较静态等权配置更具状态适应性。"
            )
        return "\n".join(lines)
