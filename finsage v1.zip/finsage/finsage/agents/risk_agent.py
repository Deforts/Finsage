"""RiskAgent：对 ResearchAgent 信号做合规与风险校验。

硬性规则优先（单因子暴露上限、情绪极端、波动过高、流动性占位等）；
LLM 仅做文字归纳，不修改数值结论。输出风险清单与降级建议。
"""

from __future__ import annotations

from ..config import FACTOR_CN, FACTOR_NAMES, STATIC_WEIGHTS
from .base import BaseAgent


class RiskAgent(BaseAgent):
    name = "RiskAgent"
    role = "风控合规专家：对投研信号做规则化风险校验"
    system_prompt = (
        "你是风控合规官。只做规则化校验与文字归纳，不修改任何数值结论。"
        "输出风险清单与降级建议。"
    )

    def run(self, state: dict) -> dict:
        research = state["research"]
        market = state["market"]
        pool = state["pool"]
        w = research["dynamic_weights"]
        bt = state["backtest"]
        risks = []
        downgrades = []

        # 1) 单因子暴露过高
        for f in FACTOR_NAMES:
            if w.get(f, 0) > 0.40:
                risks.append(f"{FACTOR_CN[f]}因子权重 {w[f]:.0%} 偏高，存在单一因子暴露风险")
                downgrades.append(f"对 {FACTOR_CN[f]} 权重设上限（建议≤40%）")

        # 2) 情绪极端负面
        sent_last = state["sentiment_panel"][-1]["sentiment"]
        neg = [c for c, s in sent_last.items() if s["score"] < -0.40]
        if neg:
            risks.append(f"存在情绪极端负面标的：{', '.join(neg)}，需关注舆情踩踏")
            downgrades.append("对情绪分<-0.4 的标的降低仓位或剔除")

        # 3) 头部持仓波动偏高
        last_factors = state["factor_panel"][-1]["factors"]
        top = research["ranking"][0]["stock"]
        if last_factors.get(top, {}).get("volatility", 0) < -0.50:
            risks.append(f"头部持仓 {top} 波动率因子 {last_factors[top]['volatility']:.2f}，波动偏高")
            downgrades.append(f"对 {top} 设置单票仓位上限")

        # 4) 组合集中度（按得分占比近似）
        scores = [r["score"] for r in research["ranking"]]
        if scores and max(scores) > 0:
            top_share = max(scores) / (sum(max(scores) for _ in scores) + 1e-9)
            if top_share > 0.30:
                risks.append("组合得分集中度偏高，头部标的贡献过大")
                downgrades.append("引入得分阈值或等权缓冲，降低集中度")

        # 5) 动态权重相对静态等权偏离过大（regime 判断风险）
        max_dev = max(abs(w[f] - STATIC_WEIGHTS[f]) for f in FACTOR_NAMES)
        if max_dev > 0.15:
            f_dev = max(FACTOR_NAMES, key=lambda f: abs(w[f] - STATIC_WEIGHTS[f]))
            risks.append(
                f"动态权重相对静态等权在 {FACTOR_CN[f_dev]} 上偏离 {max_dev:.0%}，"
                f"需复核市场状态（regime）判断的稳健性"
            )
            downgrades.append("对动态权重做平滑处理或设定偏离阈值（如≤15%）")

        # 6) 回撤预警
        if bt["dynamic"]["max_drawdown"] < -0.10:
            risks.append(
                f"动态策略样本内最大回撤 {bt['dynamic']['max_drawdown']:.1%}，"
                f"超过 10% 预警线，需关注极端行情下的尾部风险"
            )
            downgrades.append("引入止损或波动率目标化仓位管理")

        # 7) 市场情绪整体偏谨慎
        avg_sent = sum(s["score"] for s in sent_last.values()) / max(len(sent_last), 1)
        if avg_sent < -0.20:
            risks.append(f"股票池平均情绪分 {avg_sent:+.2f}，市场情绪整体偏谨慎")
            downgrades.append("降低整体仓位或提高现金比例")

        # 8) 流动性（数据层面占位，措辞专业化）
        risks.append(
            "数据层面未纳入换手率与成交额阈值约束，流动性风险敞口未量化，实盘需补充"
        )

        summary = self._summarize(risks)
        state["risks"] = {
            "list": risks,
            "downgrades": downgrades,
            "summary": summary,
            "count": len(risks),
        }
        return state

    def _summarize(self, risks: list) -> str:
        if not risks:
            return "未发现显著风险，信号通过合规校验。"
        text = "；".join(risks[:3])
        return f"共识别 {len(risks)} 项风险，重点包括：{text}。"

        # LLM 归纳（可选）
        # out = self._llm("归纳以下风险：" + "\n".join(risks), lambda: "")
        # return out or default
