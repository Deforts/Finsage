"""Agent 基类：统一定义角色 / 输入输出 Schema / 工具 / 禁止行为。

所有 Agent 遵循同一约定：
  - 输入：共享 state（dict），按需读取上游字段；
  - 输出：把自己的结果写回 state 并返回；
  - 禁止行为：禁止编造数据、禁止无依据断言；LLM 仅在 Key 可用时调用，
    否则使用确定性 fallback（保证离线可跑）。
"""

from __future__ import annotations

from typing import Any, Callable, Dict

from ..llm import LLMClient, LLMUnavailable, get_client


class BaseAgent:
    name: str = "base"
    role: str = ""
    system_prompt: str = ""

    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm or get_client()

    def _llm(self, user: str, fallback: Callable[[], str]) -> str:
        """优先调真实 LLM；未配置 Key 时走 fallback。"""
        if not self.llm.available:
            return fallback()
        try:
            return self.llm.complete(self.system_prompt, user)
        except LLMUnavailable:
            return fallback()
        except Exception as e:  # noqa: BLE001
            return fallback()

    def run(self, state: Dict[str, Any]) -> Dict[str, Any]:  # pragma: no cover
        raise NotImplementedError
