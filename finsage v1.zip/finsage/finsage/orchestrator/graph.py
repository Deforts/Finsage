"""多智能体编排器：LangGraph 依赖图 + 无依赖兜底编排器。

依赖关系（呼应需求文档第 3/4 节）：
    load ──► FactorAgent ──┐
                           ├─► ResearchAgent ──► RiskAgent ──► ReporterAgent ──► 用户
    load ──► SentimentAgent┘

LangGraph 优先；若环境无法导入 langgraph（版本/依赖问题），自动降级为
自研轻量编排器（Factor 与 Sentiment 并行，其余串行），保证可跑。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict

from ..config import FACTOR_CN, FACTOR_NAMES
from ..data import DataProvider
from ..agents import (
    FactorAgent, ResearchAgent, ReporterAgent, RiskAgent, SentimentAgent,
)
from ..rag import Doc, VectorStore
from .state import State


# --------------------------------------------------------------------------
# 进度回调（供 UI 实时展示智能体执行阶段）
# --------------------------------------------------------------------------
# 由 run_pipeline(on_progress=...) 注入；节点在完成自身工作后调用 _emit 上报。
# UI 侧回调一般直接调用 streamlit 组件，因此**只在主线程串行阶段触发**；
# 兜底编排器的 Factor/Sentiment 并行段在线程 join 之后由主线程统一上报。
_PROGRESS_CB = None

# 全链路阶段总数：载入 → 因子 → 情绪 → 研究 → 风控 → 报告
TOTAL_STAGES = 6


def _emit(step: int, label: str) -> None:
    """上报进度（step 从 1 开始）。回调异常一律吞掉，绝不影响主链路。"""
    cb = _PROGRESS_CB
    if cb is None:
        return
    try:
        cb(step, TOTAL_STAGES, label)
    except Exception:  # noqa: BLE001
        pass


# --------------------------------------------------------------------------
# 节点函数
# --------------------------------------------------------------------------
def _factor_docs() -> list:
    return [
        Doc("f_size", "规模因子(size)：小盘溢价视角，市值越小越优，工程上以 -log(市值) 代理。"),
        Doc("f_value", "价值因子(value)：估值越低越优，以盈利收益率 EP=1/PE（随价格动态）度量。"),
        Doc("f_momentum", "动量因子(momentum)：过去一段时间（跳过近 5 日）的累计收益，反映趋势延续。"),
        Doc("f_vol", "波动率因子(volatility)：近 20 日收益标准差，越低越优，属防御属性。"),
        Doc("f_quality", "质量因子(quality)：以 ROE 度量盈利质量，越高越优。"),
        Doc("f_dynamic", "动态因子配置：相较静态等权基准，动态权重可随市场状态（regime）切换因子倾斜方向——"
                         "在动量扩张期增配趋势类因子，在防御期增配低波动与质量因子，"
                         "从而提升组合在不同市场环境下的适应性与稳健性。"),
    ]


def load_data(state: State) -> Dict[str, Any]:
    pool = state["pool"]
    start, end = state["start"], state["end"]
    source = state.get("data_source", "akshare")
    news_limit = state.get("news_limit", 20)

    provider = DataProvider(source=source, news_limit=news_limit)
    market = provider.load(pool, start, end)

    docs = _factor_docs()
    for code, sd in market.items():
        for n in sd.news[:5]:
            docs.append(Doc(f"news_{code}_{n['date']}",
                            f"{n['title']} {n['content']}", {"stock": code}))
    store = VectorStore()
    store.ingest(docs)
    ctx = [d.text for d in store.search(
        "动态因子权重 五类风格因子 规模 价值 动量 波动率 质量", k=3)]

    _emit(1, f"数据载入完成（{len(market)} 只标的），因子知识库检索完成")
    return {"market": market, "rag_store": store, "rag_context": ctx}


def factor_node(state: State) -> Dict[str, Any]:
    # 每个节点只回写自己负责的字段，避免并行节点对同一 key 重复写入
    s = FactorAgent().run(dict(state))
    _emit(2, f"五类风格因子计算完成（{len(state.get('pool', []))} 只 × 5 因子）")
    return {
        "factor_panel": s["factor_panel"],
        "factor_mat": s["factor_mat"],
        "period_ret_mat": s["period_ret_mat"],
        "rebalance_dates": s["rebalance_dates"],
        "_factor_synthetic": s.get("_factor_synthetic", False),
        "_synthetic_map": s.get("_synthetic_map", {}),
    }


def sentiment_node(state: State) -> Dict[str, Any]:
    s = SentimentAgent().run(dict(state))
    _emit(3, "舆情情绪研判完成（LLM 打分 + 词典兜底）")
    return {"sentiment_panel": s["sentiment_panel"], "sent_mat": s["sent_mat"]}


def research_node(state: State) -> Dict[str, Any]:
    s = ResearchAgent().run(dict(state))
    _emit(4, "动态因子权重与回测完成")
    return {"research": s["research"], "backtest": s["backtest"]}


def risk_node(state: State) -> Dict[str, Any]:
    s = RiskAgent().run(dict(state))
    _emit(5, f"风险校验完成（识别 {s['risks'].get('count', 0)} 项风险）")
    return {"risks": s["risks"]}


def reporter_node(state: State) -> Dict[str, Any]:
    s = ReporterAgent().run(dict(state))
    _emit(6, "投研报告与组合建议生成完成")
    return {"report": s["report"], "advice": s.get("advice", [])}


# --------------------------------------------------------------------------
# LangGraph 构建
# --------------------------------------------------------------------------
def build_langgraph():
    from langgraph.graph import StateGraph, END  # 延迟导入，失败即降级

    g = StateGraph(State)
    g.add_node("load", load_data)
    g.add_node("factor", factor_node)
    g.add_node("sentiment", sentiment_node)
    g.add_node("research", research_node)
    g.add_node("risk", risk_node)
    g.add_node("reporter", reporter_node)

    g.set_entry_point("load")
    g.add_edge("load", "factor")
    g.add_edge("load", "sentiment")
    g.add_edge("factor", "research")
    g.add_edge("sentiment", "research")
    g.add_edge("research", "risk")
    g.add_edge("risk", "reporter")
    g.add_edge("reporter", END)
    return g.compile()


# --------------------------------------------------------------------------
# 兜底编排器（无 langgraph 依赖）
# --------------------------------------------------------------------------
def _run_fallback(init: Dict[str, Any]) -> Dict[str, Any]:
    state: Dict[str, Any] = dict(init)
    state.update(load_data(state))  # 合并，保留 pool/start/end 等初始字段
    _emit(1, f"数据载入完成（{len(state.get('market', {}))} 只标的），因子知识库检索完成")

    # Factor 与 Sentiment 并行预热（各自基于 state 拷贝，避免并发改同一 dict）
    def run_factor():
        return FactorAgent().run(dict(state))

    def run_sentiment():
        return SentimentAgent().run(dict(state))

    with ThreadPoolExecutor(max_workers=2) as ex:
        f1 = ex.submit(run_factor)
        f2 = ex.submit(run_sentiment)
        s1, s2 = f1.result(), f2.result()
    # 并行段不回调（子线程不宜触碰 UI 组件），join 后由主线程统一上报
    _emit(2, f"五类风格因子计算完成（{len(state.get('pool', []))} 只 × 5 因子）")
    _emit(3, "舆情情绪研判完成（LLM 打分 + 词典兜底）")
    state.update(
        {
            "factor_panel": s1["factor_panel"],
            "factor_mat": s1["factor_mat"],
            "period_ret_mat": s1["period_ret_mat"],
            "rebalance_dates": s1["rebalance_dates"],
            "_factor_synthetic": s1.get("_factor_synthetic", False),
            "_synthetic_map": s1.get("_synthetic_map", {}),
        }
    )
    state.update({"sentiment_panel": s2["sentiment_panel"], "sent_mat": s2["sent_mat"]})

    state = ResearchAgent().run(state)
    _emit(4, "动态因子权重与回测完成")
    state = RiskAgent().run(state)
    _emit(5, f"风险校验完成（识别 {state['risks'].get('count', 0)} 项风险）")
    state = ReporterAgent().run(state)
    _emit(6, "投研报告与组合建议生成完成")
    return state


# --------------------------------------------------------------------------
# 统一入口
# --------------------------------------------------------------------------
def run_pipeline(pool, start, end, top_n=5, data_source="akshare",
                 news_limit=20, use_langgraph=True,
                 on_progress=None) -> Dict[str, Any]:
    """运行完整多智能体投研链路。

    on_progress: 可选回调 `cb(step: int, total: int, label: str)`，
                 在每个阶段完成时被调用（step 从 1 开始，total=6）。
                 用于 UI 实时展示进度；回调内异常会被吞掉，不影响主链路。
    """
    global _PROGRESS_CB
    init: Dict[str, Any] = {
        "pool": list(pool),
        "start": start,
        "end": end,
        "top_n": top_n,
        "data_source": data_source,
        "news_limit": news_limit,
    }
    _PROGRESS_CB = on_progress
    try:
        if use_langgraph:
            try:
                graph = build_langgraph()
                return graph.invoke(init)
            except Exception:  # noqa: BLE001
                return _run_fallback(init)
        return _run_fallback(init)
    finally:
        _PROGRESS_CB = None
