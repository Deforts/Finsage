"""编排器共享状态 Schema（LangGraph State）。

所有 Agent 通过同一 state dict 传递数据；每个 Agent 只写自己负责的字段，
避免相互覆盖。numpy 数组等对象直接驻留内存（不启用持久化 checkpointer）。
"""

from __future__ import annotations

from typing import Any, Dict, List, TypedDict


class State(TypedDict, total=False):
    pool: List[str]
    start: str
    end: str
    top_n: int
    data_source: str
    news_limit: int
    market: Dict[str, Any]
    rag_store: Any
    rag_context: List[str]
    factor_panel: Any
    factor_mat: Any
    period_ret_mat: Any
    rebalance_dates: List[str]
    _factor_synthetic: bool
    sentiment_panel: Any
    sent_mat: Any
    research: Dict[str, Any]
    backtest: Dict[str, Any]
    risks: Dict[str, Any]
    report: str
    # 组合建议（ReporterAgent 产出）：Top-N 标的的动作/仓位/持有期
    advice: List[Dict[str, Any]]
