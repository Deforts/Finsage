"""FinSage Streamlit 交互演示页。

运行方式（两种均可）：
    1) streamlit run app.py
    2) python app.py          ← 支持直接运行，见下方 _launch_streamlit()
       （VSCode 右上角的 ▶「Run Python File」按钮走的就是这一种）

页面用真实 LLM（若已配置 ~/.env / finsage/.env 中的 OPENAI_API_KEY）或离线兜底运行
同一套多智能体投研链路，并以专业图表呈现"动态配置优于静态等权"的核心结论。
"""

from __future__ import annotations

import datetime as dt
import io
import json
import os
import threading
import time
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAVE_PLOTLY = True
except Exception:  # noqa: BLE001
    HAVE_PLOTLY = False

from finsage.config import (
    FACTOR_CN, FACTOR_NAMES, DEFAULT_POOL, STATIC_WEIGHTS, CONFIG,
)
from finsage.orchestrator import run_pipeline
from finsage.agents.sentiment_agent import SentimentAgent
from finsage import _tasks   # 后台任务表（独立模块，跨 rerun 存活）

# 舆情研判的大模型调用上限（用于页面提示"为什么慢"）
SENTIMENT_LLM_CAP = getattr(SentimentAgent, "LLM_CAP", 12)


# --------------------------------------------------------------------------
# 支持「python app.py」直接启动（VSCode 右上角 ▶ / Run Python File）
# --------------------------------------------------------------------------
def _launch_streamlit() -> None:
    """让 `python app.py` 等价于 `streamlit run app.py`。

    背景：VSCode 右上角的 ▶ 本质是执行 `python app.py`，而 Streamlit 应用
    必须由 `streamlit run` 启动，否则所有 st.* 调用都会报
    "missing ScriptRunContext!" 且页面起不来。这里检测到「被 python 直接执行」
    时，自动用官方 CLI 重新拉起自己。

    判断是否为「直接执行」用 sys.argv[0] 是否指向本文件：
      - python app.py                    → argv[0] 是本文件   → 需重新启动 ✅
      - streamlit run app.py             → argv[0] 是 streamlit 入口 → 正常渲染 ✅
      - 本函数拉起的子进程（同上一行）   → 同上               → 正常渲染 ✅
    环境变量 FINSAGE_STREAMLIT 作为第二道保险，防止任何边缘情况无限套娃。
    """
    import subprocess
    import sys

    if os.environ.get("FINSAGE_STREAMLIT") == "1":
        return  # 已在 streamlit runtime 内，继续正常渲染页面
    try:
        if os.path.abspath(sys.argv[0]) != os.path.abspath(__file__):
            return  # 由 streamlit server 加载，无需重新启动
    except Exception:  # noqa: BLE001
        return

    target = os.path.abspath(__file__)
    # flush=True：VSCode 集成终端里 stdout 是管道（块缓冲），不加会延迟显示甚至丢失
    print(f"[FinSage] 检测到直接运行，正在以 Streamlit 方式启动：{target}", flush=True)
    print("[FinSage] 启动后请访问 http://localhost:8501（按 Ctrl+C 结束）", flush=True)
    env = dict(os.environ, FINSAGE_STREAMLIT="1")
    # 用 sys.executable 保证走当前虚拟环境的 python；target 用绝对路径，
    # 这样即使 VSCode 的 cwd 是工作区根目录（而非 app.py 所在目录）也能找到文件
    proc = subprocess.Popen([sys.executable, "-m", "streamlit", "run", target], env=env)
    try:
        sys.exit(proc.wait())
    except BaseException:
        # 父进程被中断（Ctrl+C / VSCode 停止按钮）时，必须让子进程一起退出，
        # 否则 streamlit 会变成孤儿进程继续占用 8501，下次启动就端口冲突
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            proc.kill()
        raise


if __name__ == "__main__":
    # 必须在第一个 st.* 调用之前执行，否则直接运行时会刷一堆 ScriptRunContext 警告
    _launch_streamlit()

# --------------------------------------------------------------------------
# 模型配置的跨会话持久化
# --------------------------------------------------------------------------
# 写在项目根目录 .user_config.json（与 .env 同级），已加入 .gitignore，
# 因此本机可长期保存，而推送 GitHub 时不会带上任何 URL / Key。
_USER_CONFIG_PATH = Path(__file__).resolve().parent / ".user_config.json"


def _mirror_llm_cfg() -> None:
    """把 widget key（llm_*）的值镜像到持久 key（cfg_*）。

    关键：带 key 的 widget 因 toggle 收起而消失后，Streamlit 会清掉
    它的 session_state（llm_*）——所以真源必须放在**非 widget key**（cfg_*），
    widget 渲染时用 value=cfg_* 回填，输入时 on_change 镜像回来。
    """
    st.session_state["cfg_base_url"] = st.session_state.get("llm_base_url", "")
    st.session_state["cfg_models_raw"] = st.session_state.get("llm_models_raw", "")
    st.session_state["cfg_api_key"] = st.session_state.get("llm_api_key", "")


def _persist_user_config() -> None:
    """把模型配置写入 .user_config.json（读持久 key cfg_*，非 widget key）。

    **空配置一律不落盘**：无头运行（AppTest/CLI）的 session 里 cfg_* 全空，
    若无条件写盘会把用户已保存的真实配置覆盖成空值（踩过的坑）。
    用户想清空请用「🗑 清空」按钮（显式删文件）。
    """
    data = {
        "base_url": st.session_state.get("cfg_base_url", ""),
        "models_raw": st.session_state.get("cfg_models_raw", ""),
        "api_key": st.session_state.get("cfg_api_key", ""),
    }
    if not any(data.values()):
        return
    try:
        _USER_CONFIG_PATH.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:  # noqa: BLE001
        pass


def _on_confirm_config() -> None:
    """「确认并保存」的 on_click 回调：镜像 + 落盘 + 收起 + 显示成功提示。

    on_click 回调在 rerun 最开始、所有 widget 实例化之前执行，
    此时修改 session_state（含 widget key）是安全的；
    若在按钮 click 分支（widget 已实例化）里改，会抛
    StreamlitWidgetAlreadyInstantiatedError。
    """
    _mirror_llm_cfg()
    _persist_user_config()
    st.session_state["_llm_cfg_toggle"] = False
    st.session_state["_cfg_saved_msg"] = True


def _on_clear_config() -> None:
    """「清空」的 on_click 回调：清空三框 + 收起 + 删除本地配置文件。"""
    for k in ("llm_base_url", "llm_models_raw", "llm_api_key",
              "cfg_base_url", "cfg_models_raw", "cfg_api_key"):
        st.session_state[k] = ""
    st.session_state["_llm_cfg_toggle"] = False
    st.session_state["_skip_persist_once"] = True   # 防止 rerun 兜底落盘复活空文件
    try:
        _USER_CONFIG_PATH.unlink(missing_ok=True)
    except Exception:  # noqa: BLE001
        pass


# --------------------------------------------------------------------------
# PDF 报告（用于下载按钮）
# --------------------------------------------------------------------------
_CJK_FONT_REGISTERED = False
_SONG_NAME = "FinSageSong"       # 宋体 Regular（正文）
_SONG_BOLD = "FinSageSongBold"   # 宋体 Bold（标题 / <b> 强调）
_HEI_NAME = "FinSageHei"         # 黑体（备用）


def _find_cjk_font() -> dict:
    """返回可用的 CJK 字体路径：{"song": 宋体, "hei": 黑体}；缺项为 None。

    macOS 的宋体/黑体都是 .ttc 集合，reportlab 的 TTFont 需用 subfontIndex 读取
    （实测 Songti.ttc idx=0、STHeiti Light.ttc idx=0 均可；Hiragino 的 posts 表不兼容）。
    """
    cands_song = [
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/System/Library/Fonts/Songti.ttc",
        "/Library/Fonts/Songti.ttc",
    ]
    cands_hei = [
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
    ]
    return {
        "song": next((p for p in cands_song if os.path.exists(p)), None),
        "hei": next((p for p in cands_hei if os.path.exists(p)), None),
    }


def _register_cjk_font() -> tuple:
    """注册宋体 Regular / 宋体 Bold / 黑体，返回 (song, song_bold, hei)。

    标题与 <b> 强调都用**宋体 Bold** 而非黑体：黑体的顿号"、"
    字形天生居中（用户已反馈不像中文标点），宋体 Bold 的顿号靠左下。
    registerFontFamily 让 <b> 标签映射到宋体 Bold。
    """
    global _CJK_FONT_REGISTERED
    paths = _find_cjk_font()
    song = song_bold = hei = "Helvetica"
    if not _CJK_FONT_REGISTERED:
        try:
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            if paths["song"]:
                # Songti.ttc 子字体：0=Black 1=SC-Bold 3=SC-Light
                # 6=SC-Regular（正文）/ 7=TC-Regular
                pdfmetrics.registerFont(TTFont(
                    _SONG_NAME, paths["song"], subfontIndex=6))
                pdfmetrics.registerFont(TTFont(
                    _SONG_BOLD, paths["song"], subfontIndex=1))
                song, song_bold = _SONG_NAME, _SONG_BOLD
                pdfmetrics.registerFontFamily(
                    _SONG_NAME, normal=song, bold=song_bold,
                    italic=song, boldItalic=song_bold)
            if paths["hei"]:
                pdfmetrics.registerFont(TTFont(
                    _HEI_NAME, paths["hei"], subfontIndex=0))
                hei = _HEI_NAME
            _CJK_FONT_REGISTERED = True
        except Exception:  # noqa: BLE001
            pass
    if _CJK_FONT_REGISTERED:
        return _SONG_NAME, _SONG_BOLD, _HEI_NAME
    return "Helvetica", "Helvetica", "Helvetica"


def _pdf_inline(s: str) -> str:
    """markdown 行内语法（**粗**/*斜*）转 reportlab Paragraph 的 XML 片段。"""
    import re as _re
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = _re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = _re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<i>\1</i>", s)
    return s


def _pdf_styles(song, song_bold, hei):
    """中文文档排版规范（参照通用 Word 模板惯例）：

    - 正文：宋体小四（12pt），1.5 倍行距（leading = 12 × 1.5 = 18），
      首行缩进 2 字符（24pt），段前段后均为 0（靠首行缩进区分段落）
    - 标题：**宋体 Bold**（黑体的顿号"、"字形居中，宋体的靠左下），段前段后统一
    - 段内小标题（**xxx：** 开头的段）：顶格、加粗、不缩进
    - 表格：宋体 9pt，单元格内不缩进、水平垂直居中，**不加粗**
    - 列表/引用：不缩进首行
    """
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_CENTER
    from reportlab.lib import colors
    s = dict(fontName=song, wordWrap="CJK")        # 宋体 Regular + 中文断行
    b = dict(fontName=song_bold, wordWrap="CJK")   # 宋体 Bold + 中文断行
    return {
        "h1": ParagraphStyle("h1", fontSize=16, leading=24, alignment=TA_LEFT,
                             textColor=colors.HexColor("#000000"),
                             spaceBefore=24, spaceAfter=12, **b),
        "h2": ParagraphStyle("h2", fontSize=14, leading=21, alignment=TA_LEFT,
                             textColor=colors.HexColor("#000000"),
                             spaceBefore=18, spaceAfter=8, **b),
        "h3": ParagraphStyle("h3", fontSize=12, leading=18, alignment=TA_LEFT,
                             textColor=colors.HexColor("#000000"),
                             spaceBefore=12, spaceAfter=6, **b),
        # 正文：首行缩进 2 字符（24pt），1.5 倍行距，段前段后 0
        "body": ParagraphStyle("body", fontSize=12, leading=18, alignment=TA_LEFT,
                               firstLineIndent=24, spaceBefore=0, spaceAfter=0, **s),
        # 段内小标题（**xxx：** 开头的段）：**顶格**、加粗、段前留一点空
        "subtitle": ParagraphStyle("subtitle", fontSize=12, leading=18,
                                   alignment=TA_LEFT, firstLineIndent=0,
                                   spaceBefore=10, spaceAfter=0, **b),
        # 列表项：左缩进 24pt（与正文视觉区分）
        "list": ParagraphStyle("list", fontSize=12, leading=18, alignment=TA_LEFT,
                               leftIndent=24, firstLineIndent=0,
                               spaceBefore=0, spaceAfter=0, **s),
        # 引用（报告头部的区间信息行）：小五灰色，无缩进
        "quote": ParagraphStyle("quote", fontSize=9, leading=14, alignment=TA_LEFT,
                                textColor=colors.HexColor("#555555"),
                                spaceBefore=0, spaceAfter=6, **s),
        # 表格单元格：宋体 9pt 居中，无首行缩进、无加粗
        "cell": ParagraphStyle("cell", fontSize=9, leading=13.5,
                               alignment=TA_CENTER, **s),
        "head": ParagraphStyle("head", fontSize=9, leading=13.5,
                               alignment=TA_CENTER, **b),
    }


def _pdf_make_table(rows, st):
    """platypus 表格：列宽精确到磅并归一化到可用宽度（绝不溢出页面），
    单元格原生 MIDDLE 垂直居中，跨页自动重复表头。"""
    from reportlab.platypus import Table, TableStyle, Paragraph
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    import re as _re

    n_cols = max(len(r) for r in rows)
    rows = [r + [""] * (n_cols - len(r)) for r in rows]

    def tlen(s):
        return max(len(_re.sub(r"<[^>]+>", "", s).strip()), 2)

    # 每列取所有行的最大字符数，按比例分配可用宽度
    col_chars = [max(tlen(r[c]) for r in rows) for c in range(n_cols)]
    avail = A4[0] - 2 * 56.7                 # 左右各 2cm，强制对称
    widths = [max(avail * w / sum(col_chars), 30.0) for w in col_chars]
    scale = avail / sum(widths)              # 归一化：恰好占满、不越界
    widths = [w * scale for w in widths]

    data = []
    for ri, r in enumerate(rows):
        style = st["head"] if ri == 0 else st["cell"]
        data.append([Paragraph(_pdf_inline(c), style) for c in r])

    t = Table(data, colWidths=widths, repeatRows=1, hAlign="CENTER")
    ts = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#b8c4d6")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2f8")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]
    for ri in range(2, len(rows), 2):        # 斑马纹
        ts.append(("BACKGROUND", (0, ri), (-1, ri), colors.HexColor("#f7f9fc")))
    t.setStyle(TableStyle(ts))
    return t


def _pdf_md_to_flowables(md_text, st):
    """简易 markdown 解析器：标题/表格/列表/引用/分隔线 → platypus Flowables。"""
    from reportlab.platypus import Paragraph, HRFlowable, Spacer
    from reportlab.lib import colors
    import re as _re

    flows, para = [], []

    def flush():
        if para:
            txt = " ".join(para).strip()
            if txt:
                # 以 ** 开头的段 = 段内小标题（**xxx：** ...）→ 顶格、加粗
                style = st["subtitle"] if txt.startswith("**") else st["body"]
                flows.append(Paragraph(_pdf_inline(txt), style))
            para.clear()

    lines = (md_text or "").split("\n")
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if not s:
            flush()
        elif s.startswith("### "):
            flush(); flows.append(Paragraph(_pdf_inline(s[4:]), st["h3"]))
        elif s.startswith("## "):
            flush(); flows.append(Paragraph(_pdf_inline(s[3:]), st["h2"]))
        elif s.startswith("# "):
            flush()
            flows.append(Paragraph(_pdf_inline(s[2:]), st["h1"]))
            flows.append(HRFlowable(width="100%", thickness=1.2,
                                    color=colors.HexColor("#1f3b6f"),
                                    spaceBefore=0, spaceAfter=8))
        elif s.startswith("|"):
            tbl = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = lines[i].strip()
                if not _re.match(r"^\|[\s:\-|]+\|$", row):   # 跳过 |---| 分隔行
                    tbl.append([c.strip() for c in row.strip("|").split("|")])
                i += 1
            flush()
            if tbl:
                flows.append(_pdf_make_table(tbl, st))
                flows.append(Spacer(1, 8))
            continue
        elif s.startswith("- "):
            flush()
            flows.append(Paragraph("• " + _pdf_inline(s[2:]), st["list"]))
        elif s.startswith("> "):
            flush()
            flows.append(Paragraph(_pdf_inline(s[2:]), st["quote"]))
        elif s == "---":
            flush()
            flows.append(HRFlowable(width="100%", thickness=0.6,
                                    color=colors.HexColor("#b8c4d6"),
                                    spaceBefore=8, spaceAfter=8))
        else:
            para.append(s)
        i += 1
    flush()
    return flows


def _report_to_pdf(md_text: str) -> bytes:
    """markdown 报告 → PDF 字节（reportlab platypus 直排，不再经过 xhtml2pdf）。

    弃用 xhtml2pdf 的原因：其 CSS 支持残缺——col 宽度百分比不生效、
    表格按内容撑破容器、vertical-align 失效，导致列溢出与左右边距失衡。
    platypus 方案的优势：列宽精确到磅且归一化到可用宽度（永不溢出）、
    单元格原生 MIDDLE 垂直居中、左右边距强制对称、跨页自动重复表头、
    段落 wordWrap="CJK" 中文自然断行。
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate

    font_song, font_song_bold, font_hei = _register_cjk_font()
    st = _pdf_styles(font_song, font_song_bold, font_hei)
    flows = _pdf_md_to_flowables(md_text or "", st)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=56.7, rightMargin=56.7,   # 各 2cm，强制对称
        topMargin=45, bottomMargin=51,
        title="FinSage 投研决策报告",
    )
    try:
        doc.build(flows)
    except Exception:  # noqa: BLE001
        return b""
    return buf.getvalue()


def _report_to_docx(md_text: str) -> bytes:
    """markdown 报告 → Word (.docx) 字节，中文排版：

    - 正文：宋体小四（12pt）、1.5 倍行距、首行缩进 2 字符（24pt）
    - 标题：黑体（16/14/12pt 加粗、顶格）
    - 段内小标题（**xxx：** 开头的段）：顶格、加粗
    - 表格：Table Grid、单元格水平垂直居中、表头黑体
    - 西文/数字：Times New Roman（run.font.name），中文（eastAsia）宋体/黑体
    """
    import re as _re
    from docx import Document
    from docx.shared import Pt
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT

    def set_run_font(run, east="宋体", size=12, bold=False):
        """同时设置西文（Times New Roman）与中文（eastAsia）字体。"""
        run.font.name = "Times New Roman"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), east)
        run.font.size = Pt(size)
        run.bold = bold

    def add_rich(par, text, size=12, east="宋体"):
        """解析 **bold** → runs；加粗片段用黑体（中文强调习惯）。"""
        pos = 0
        for m in _re.finditer(r"\*\*(.+?)\*\*", text):
            if m.start() > pos:
                set_run_font(par.add_run(text[pos:m.start()]), east=east, size=size)
            set_run_font(par.add_run(m.group(1)), east="黑体", size=size, bold=True)
            pos = m.end()
        if pos < len(text):
            set_run_font(par.add_run(text[pos:]), east=east, size=size)

    def fmt(par, indent=False, before=0, after=0, align=None, spacing=1.5):
        pf = par.paragraph_format
        pf.line_spacing = spacing
        pf.space_before = Pt(before)
        pf.space_after = Pt(after)
        if indent:
            pf.first_line_indent = Pt(24)
        if align is not None:
            par.alignment = align

    doc = Document()
    para = []

    def flush():
        if not para:
            return
        txt = " ".join(para).strip()
        para.clear()
        if not txt:
            return
        p = doc.add_paragraph()
        add_rich(p, txt)
        # 以 ** 开头的段 = 段内小标题 → 顶格；其余正文首行缩进 2 字符
        fmt(p, indent=not txt.startswith("**"))

    lines = (md_text or "").split("\n")
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if not s:
            flush()
        elif s.startswith("### "):
            flush()
            p = doc.add_paragraph()
            add_rich(p, s[4:], east="黑体")
            fmt(p, before=12, after=6)
            for r in p.runs:
                set_run_font(r, east="黑体", size=12, bold=True)
        elif s.startswith("## "):
            flush()
            p = doc.add_paragraph()
            add_rich(p, s[3:], east="黑体")
            fmt(p, before=18, after=8)
            for r in p.runs:
                set_run_font(r, east="黑体", size=14, bold=True)
        elif s.startswith("# "):
            flush()
            p = doc.add_paragraph()
            add_rich(p, s[2:], east="黑体")
            fmt(p, before=24, after=12, align=WD_ALIGN_PARAGRAPH.CENTER)
            for r in p.runs:
                set_run_font(r, east="黑体", size=16, bold=True)
        elif s.startswith("|"):
            tbl = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = lines[i].strip()
                if not _re.match(r"^\|[\s:\-|]+\|$", row):   # 跳过分隔行
                    tbl.append([c.strip() for c in row.strip("|").split("|")])
                i += 1
            flush()
            if tbl:
                n = max(len(r) for r in tbl)
                t = doc.add_table(rows=len(tbl), cols=n)
                t.style = "Table Grid"
                t.alignment = WD_TABLE_ALIGNMENT.CENTER
                # 列宽：短内容列给足需求（动作列等不折行），超宽时只压缩
                # 需求最大的长描述列；有富余时富余也归描述列。
                def _cell_w(text):
                    text = _re.sub(r"<[^>]+>", "", text).strip()
                    w = sum(9 if ord(c) > 0x2E80 else 5 for c in text)
                    return max(w, 18) + 12          # 内容宽 + 单元格左右内边距
                avail_pt = 450                       # A4 内容区 ≈ 15.9cm
                need = [max(_cell_w(r[ci] if ci < len(r) else "")
                            for r in tbl) for ci in range(n)]
                extra = avail_pt - sum(need)
                if extra >= 0:
                    need[-1] += extra                # 富余全给描述列
                else:
                    over = -extra
                    while over > 0:                  # 只压最宽列，短列保需求
                        c_max = max(range(n), key=lambda c: need[c])
                        cut = min(need[c_max] - 30, over)   # 每列最少保 30pt
                        if cut <= 0:
                            break
                        need[c_max] -= cut
                        over -= cut
                widths = [int(w) for w in need]
                t.autofit = False
                for row in t.rows:
                    for ci, cell in enumerate(row.cells):
                        # 必须包 Pt()：裸 int 会被当成 EMU（≈0），列宽形同未设
                        cell.width = Pt(widths[ci])
                for ri, row in enumerate(tbl):
                    for ci in range(n):
                        cell_p = t.cell(ri, ci).paragraphs[0]
                        add_rich(cell_p, row[ci] if ci < len(row) else "",
                                 size=9, east="黑体" if ri == 0 else "宋体")
                        fmt(cell_p, align=WD_ALIGN_PARAGRAPH.CENTER, spacing=1.0)
                doc.add_paragraph()   # 表格后留一个空段，避免与下文贴死
            continue
        elif s.startswith("- "):
            flush()
            p = doc.add_paragraph()
            add_rich(p, "• " + s[2:])
            fmt(p)                    # 列表项顶格，不缩进
        elif s.startswith("> "):
            flush()
            p = doc.add_paragraph()
            add_rich(p, s[2:])
            fmt(p, after=6)
            for r in p.runs:
                r.font.size = Pt(9)
        elif s == "---":
            flush()
        else:
            para.append(s)
        i += 1
    flush()

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


FONT = "Microsoft YaHei, PingFang SC, SimHei, sans-serif"

# 必须在第一个 st.* 命令前调用
try:
    st.set_page_config(
        page_title="FinSage 多智能体投研决策系统",
        page_icon="🛠",
        layout="wide",
        initial_sidebar_state="expanded",
        toolbar_mode="minimal",   # streamlit 1.40+ 隐藏右上角 Deploy 按钮
    )
except TypeError:
    st.set_page_config(
        page_title="FinSage 多智能体投研决策系统",
        page_icon="🛠",
        layout="wide",
        initial_sidebar_state="expanded",
    )


# --------------------------------------------------------------------------
# 工具函数
# --------------------------------------------------------------------------
def _resolve_pool(spec: str):
    spec = (spec or "").strip()
    if spec.upper() in ("HS300", "沪深300", "DEFAULT", ""):
        return list(DEFAULT_POOL)
    if spec.upper() in ("ZZ500", "中证500"):
        return [
            "600031.SH", "600585.SH", "600837.SH", "600893.SH", "601066.SH",
            "000001.SZ", "000063.SZ", "000651.SZ", "002415.SZ", "300059.SZ",
        ]
    return [c.strip() for c in spec.split(",") if c.strip()]


def _agent_trace_html(state: dict) -> str:
    """运行后展示 5 个智能体各自产出的摘要卡片，提升演示可讲解性。"""
    research = state.get("research", {})
    w_dyn = research.get("dynamic_weights", {})
    ranking = research.get("ranking", [])
    risks = state.get("risks", {})
    sent = state.get("sentiment_panel", [])
    pool = state.get("pool", [])

    ordered = sorted(w_dyn.items(), key=lambda x: -x[1])
    top2 = "、".join(f"{FACTOR_CN.get(k, k)} {v:.0%}" for k, v in ordered[:2]) if ordered else "—"
    top_stock = ranking[0]["stock"] if ranking else "—"
    avg_sent = 0.0
    if sent:
        last = sent[-1]["sentiment"]
        avg_sent = sum(s["score"] for s in last.values()) / max(len(last), 1)
    has_llm = "智能投研结论" in state.get("report", "")

    cards = [
        ("FactorAgent", "因子计算",
         f"{len(pool)} 只 × 5 类风格因子，已完成截面 z-score 标准化"),
        ("SentimentAgent", "舆情研判",
         f"股票池平均情绪分 {avg_sent:+.2f}，真实 LLM 调用设上限保护"),
        ("ResearchAgent", "动态配置",
         f"动态权重 Top2：{top2}；综合得分第一 {top_stock}"),
        ("RiskAgent", "风险校验",
         f"识别 {risks.get('count', 0)} 项风险，并给出降级建议"),
        ("ReporterAgent", "报告生成",
         f"结构化报告已生成{'，含 LLM 投研结论' if has_llm else ''}"),
    ]
    inner = "".join(
        f'<div class="fs-card"><div class="nm">{n}</div>'
        f'<div class="rl">{r}</div><div>{s}</div></div>'
        for n, r, s in cards
    )
    return (f'<div style="display:grid; grid-template-columns:repeat(5,1fr); '
            f'gap:.6rem;">{inner}</div>')


# --------------------------------------------------------------------------
# 图表
# --------------------------------------------------------------------------
def chart_backtest(bt):
    dyn = bt["dynamic"]["equity"]
    sta = bt["static_equalweight"]["equity"]
    eqa = bt["equal_all"]["equity"]
    df = pd.DataFrame(
        {"动态因子权重": dyn, "静态等权因子": sta, "全样本等权": eqa},
    )
    df.index.name = "再平衡期次"
    fig = px.line(
        df, x=df.index, y=df.columns, markers=False,
        labels={"value": "组合净值（起点 = 1.0）", "variable": "策略"},
        color_discrete_sequence=["#d62728", "#1f77b4", "#7f7f7f"],
    )
    fig.update_layout(
        font_family=FONT, height=380, margin=dict(l=20, r=20, t=30, b=20),
        legend=dict(orientation="h", y=1.08, x=0),
        xaxis_title="", yaxis_title="净值",
    )
    return fig


def chart_weights(w_dyn, w_static):
    df = pd.DataFrame({
        "因子": [FACTOR_CN[f] for f in FACTOR_NAMES],
        "动态权重": [w_dyn.get(f, 0) for f in FACTOR_NAMES],
        "静态等权": [w_static.get(f, 0) for f in FACTOR_NAMES],
    })
    fig = px.bar(
        df, x="因子", y=["动态权重", "静态等权"], barmode="group",
        color_discrete_sequence=["#d62728", "#1f77b4"],
        labels={"value": "权重", "variable": "配置方式"},
    )
    fig.update_layout(
        font_family=FONT, height=360, margin=dict(l=20, r=20, t=30, b=20),
        legend=dict(orientation="h", y=1.1, x=0),
        yaxis_tickformat=".0%",
    )
    return fig


def chart_weights_series(series, dates):
    arr = np.array(series)  # (Kp, 5)，Kp = len(rebalance_dates) - 1
    # 权重序列第 k 项对应因子日期 k（持有至 k+1），故索引取前 len(arr) 个再平衡日
    idx = [str(d) for d in (dates or [])[: len(arr)]] or list(range(len(arr)))
    df = pd.DataFrame(
        arr, columns=[FACTOR_CN[f] for f in FACTOR_NAMES], index=idx,
    )
    df.index.name = "再平衡日"
    fig = px.area(
        df, x=df.index, y=df.columns,
        labels={"value": "权重", "variable": "因子"},
        color_discrete_sequence=["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"],
    )
    fig.update_layout(
        font_family=FONT, height=360, margin=dict(l=20, r=20, t=30, b=20),
        legend=dict(orientation="h", y=1.1, x=0),
        yaxis_tickformat=".0%", xaxis_title="",
    )
    return fig


def chart_scores(ranking, top_n):
    """全池子综合得分排名 + Top-N 高亮。

    原实现只画 Top-N，会让人看不到"为什么选这几只"的筛选依据；
    改为画全部标的，把进入组合的 Top-N 高亮、其余淡化，
    一张图同时满足「看决策」和「看对比」两个需求。
    """
    df = pd.DataFrame(ranking)          # 画全部，不再切片
    n = len(df)
    eff_n = max(min(top_n, n), 1)       # 与组合建议一致：N 不超过池子只数
    df["组别"] = [
        f"进入组合 Top-{eff_n}" if i < eff_n else "未入选"
        for i in range(n)
    ]
    buy_lbl = f"进入组合 Top-{eff_n}"
    fig = px.bar(
        df, x="stock", y="score", text="score", color="组别",
        labels={"score": "综合得分", "stock": "标的", "组别": ""},
        color_discrete_map={buy_lbl: "#d62728", "未入选": "#c8ccd4"},
        category_orders={"组别": [buy_lbl, "未入选"]},
    )
    fig.update_traces(texttemplate="%{text:.3f}", textposition="outside")
    fig.update_layout(
        font_family=FONT, height=360, margin=dict(l=20, r=20, t=34, b=20),
        xaxis_title="", yaxis_title="综合得分",
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    xanchor="right", x=1, title=None),
    )
    return fig


def _fmt_date(v) -> str:
    """把调仓日统一格式化为 YYYY-MM-DD。

    rebalance_dates 里存的是 pandas Timestamp（带微秒精度），
    直接 str() 会显示成 "2025-01-31 00:00:00.000001" 这类脏标签。
    """
    s = str(v)
    if len(s) >= 10 and s[4] == "-" and s[7] == "-":
        return s[:10]
    try:
        return pd.Timestamp(v).strftime("%Y-%m-%d")
    except Exception:  # noqa: BLE001
        return s[:10]


def chart_sentiment(panel, pool):
    dates = [_fmt_date(p["date"]) for p in panel]
    mat = np.zeros((len(dates), len(pool)))
    for i, p in enumerate(panel):
        for j, c in enumerate(pool):
            mat[i, j] = p.get("sentiment", {}).get(c, {}).get("score", 0.0)
    fig = go.Figure(go.Heatmap(
        z=mat, x=pool, y=dates, zmid=0,
        colorscale="RdBu", colorbar=dict(title="情绪分"),
        hovertemplate="标的 %{x}<br>日期 %{y}<br>情绪分 %{z:.2f}<extra></extra>",
    ))
    fig.update_layout(
        font_family=FONT, height=340, margin=dict(l=20, r=20, t=30, b=20),
        xaxis_title="", yaxis_title="再平衡日", yaxis=dict(autorange="reversed"),
    )
    return fig


# --------------------------------------------------------------------------
# 页面骨架
# --------------------------------------------------------------------------
st.set_page_config(
    page_title="FinSage · 多智能体投研决策", layout="wide",
)

st.markdown(
    """
    <style>
    .block-container { padding-top: 2.8rem; max-width: 100%; }
    .fs-title {
        font-size: 1.5rem; font-weight: 700; color: #1f3b6f;
        margin-top: .2rem; margin-bottom: .15rem; line-height: 1.4;
        white-space: normal; word-break: keep-all; overflow-wrap: anywhere;
    }
    .fs-sub { color: #555; font-size: .95rem; margin-bottom: 1rem; }
    .fs-banner {
        background: #fdecea; border-left: 5px solid #d62728; color: #8a1f17;
        padding: .55rem .8rem; border-radius: 6px; font-size: .85rem; margin-bottom: 1rem;
    }
    .fs-arch {
        background: linear-gradient(180deg, #f8fafc 0%, #fff 100%);
        border: 1px solid #e2e8f0; border-radius: 10px;
        padding: 1rem 0.9rem; font-size: 0.9rem; line-height: 1.7; color: #334155;
        box-shadow: 0 1px 3px rgba(15,23,42,0.04);
    }
    /* 横向流程：5 个智能体色卡 + 数据层 + 箭头 */
    .fs-flow {
        display: flex; align-items: center; gap: 0.25rem;
        margin: 0.25rem 0 0.6rem; padding: 0.25rem 0;
        overflow-x: auto;
    }
    .fs-flow-col {
        display: flex; flex-direction: column; gap: 0.35rem;
        align-items: center; min-width: 138px;
    }
    .fs-flow-arrow {
        font-size: 1.1rem; color: #94a3b8; flex-shrink: 0;
        padding: 0 0.15rem; user-select: none;
    }
    .fs-flow-merge {
        font-size: 0.7rem; color: #64748b; padding: 0.05rem 0;
        font-weight: 600; letter-spacing: 0.05em;
    }
    .fs-node {
        background: #fff; border: 1px solid #e2e8f0;
        border-left: 4px solid #475569; border-radius: 8px;
        padding: 0.5rem 0.6rem; text-align: center; width: 138px;
        box-shadow: 0 1px 2px rgba(15,23,42,0.05);
    }
    .fs-node-final {
        background: linear-gradient(135deg, #f0fdf4 0%, #fff 70%);
        border-color: #86efac; border-left-color: #15803d;
    }
    .fs-node-icon { font-size: 1.25rem; line-height: 1.1; }
    .fs-node-name {
        font-weight: 700; color: #0f172a; font-size: 0.83rem;
        margin-top: 0.18rem; letter-spacing: 0.01em;
    }
    .fs-node-sub {
        color: #64748b; font-size: 0.69rem; margin-top: 0.18rem;
        line-height: 1.35; letter-spacing: 0.01em;
    }
    .fs-agent { font-weight:600; color:#1f3b6f; }
    .metric-big { font-size: 1.5rem; font-weight: 700; }
    .fs-card {
        background:#fff; border:1px solid #dbe4f3; border-left:4px solid #1f3b6f;
        border-radius:8px; padding:.55rem .65rem; font-size:.8rem; line-height:1.5;
        height:100%;
    }
    .fs-card .nm { font-weight:700; color:#1f3b6f; font-size:.92rem; }
    .fs-card .rl { color:#888; font-size:.72rem; margin:.1rem 0 .25rem; }

    /* 隐藏 streamlit 内置英文元素（Deploy、菜单、Footer、装饰条、角标）
       注意：不能整体隐藏 [data-testid="stToolbar"]！侧边栏折叠后的「展开」按钮
       （collapsedControl）就挂在工具栏里，整体隐藏会导致侧边栏收起后无法再打开。
       因此只隐藏工具栏中具体的多余子元素。 */
    [data-testid="stDecoration"],
    [data-testid="stFooter"],
    [data-testid="manage-this-app-btn"],
    [data-testid="stAppDeployButton"],
    [data-testid="stStatusWidget"] { display: none !important; }
    /* 隐藏右上角 "..." 菜单里的 "About"/"Get help" 等英文条目 */
    #MainMenu { display: none; }
    /* 右下角的 "Made with Streamlit" */
    .viewerBadge_link__qRIco,
    a[href^="https://streamlit.io"] { display: none !important; }
    /* 确保侧边栏折叠后的展开按钮始终可见可点（避免被上面的规则误伤） */
    [data-testid="collapsedControl"] {
        display: flex !important; visibility: visible !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<div class="fs-title">FinSage · 多智能体金融投研决策系统</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="fs-sub">双通道 LSTM-Attention 融合模型 · 动态因子权重 · 情绪与风险多智能体协同</div>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="fs-banner">⚠️ 演示项目 / 非实盘交易系统 / 合成与历史数据回测不构成任何投资建议，'
    '市场有风险，决策需谨慎。</div>',
    unsafe_allow_html=True,
)

with st.expander("系统架构：5 个智能体协同（点击展开）", expanded=False):
    st.markdown(
        '<div class="fs-arch">'
        '<div class="fs-flow">'
        # 第 1 列：数据层
        '<div class="fs-flow-col">'
        '<div class="fs-node" style="border-left-color:#475569">'
        '<div class="fs-node-icon">📊</div>'
        '<div class="fs-node-name">数据层</div>'
        '<div class="fs-node-sub">行情 · 新闻 · RAG</div>'
        '</div></div>'
        '<div class="fs-flow-arrow">▶</div>'
        # 第 2 列：Factor + Sentiment 并行
        '<div class="fs-flow-col">'
        '<div class="fs-node" style="border-left-color:#1d4ed8">'
        '<div class="fs-node-icon">🔬</div>'
        '<div class="fs-node-name">FactorAgent</div>'
        '<div class="fs-node-sub">五类风格因子</div>'
        '</div>'
        '<div class="fs-flow-merge">⫴ 并行</div>'
        '<div class="fs-node" style="border-left-color:#7e22ce">'
        '<div class="fs-node-icon">💬</div>'
        '<div class="fs-node-name">SentimentAgent</div>'
        '<div class="fs-node-sub">舆情情绪打分</div>'
        '</div>'
        '</div>'
        '<div class="fs-flow-arrow">▶</div>'
        # 第 3 列：Research
        '<div class="fs-flow-col">'
        '<div class="fs-node" style="border-left-color:#c2410c">'
        '<div class="fs-node-icon">🧠</div>'
        '<div class="fs-node-name">ResearchAgent</div>'
        '<div class="fs-node-sub">LSTM-Attention<br>动态权重 · 回测</div>'
        '</div></div>'
        '<div class="fs-flow-arrow">▶</div>'
        # 第 4 列：Risk
        '<div class="fs-flow-col">'
        '<div class="fs-node" style="border-left-color:#b91c1c">'
        '<div class="fs-node-icon">⚠️</div>'
        '<div class="fs-node-name">RiskAgent</div>'
        '<div class="fs-node-sub">规则化风控</div>'
        '</div></div>'
        '<div class="fs-flow-arrow">▶</div>'
        # 第 5 列：Reporter（高亮：终态）
        '<div class="fs-flow-col">'
        '<div class="fs-node fs-node-final">'
        '<div class="fs-node-icon">📄</div>'
        '<div class="fs-node-name">ReporterAgent</div>'
        '<div class="fs-node-sub">RAG 检索 · LLM 投研结论</div>'
        '</div></div>'
        '</div>'  # /fs-flow
        '<div style="color:#64748b;font-size:.78rem;margin-top:.2rem">'
        '编排器：LangGraph StateGraph（Factor∥Sentiment → Research → Risk → Reporter）'
        '，无 LangGraph 时自动降级为 ThreadPoolExecutor 兜底编排器。'
        '</div>'
        '</div>',  # /fs-arch
        unsafe_allow_html=True,
    )

# --------------------------------------------------------------------------
# 侧边栏
# --------------------------------------------------------------------------
with st.sidebar:
    st.header("参数设置")
    pool_kind = st.selectbox(
        "股票池",
        ["沪深300 蓝筹（10 只样本）", "中证500 中盘（10 只样本）", "自定义代码（逗号分隔）"],
        index=0,
        help="沪深300：A 股市值最大的 300 只股票，系统从中挑 10 只代表性蓝筹作样本"
             "（茅台、平安、招行、五粮液、隆基、美的、恒瑞、比亚迪、中免、长江电力）。\n\n"
             "中证500：剔除沪深300 后的中盘股，系统挑 10 只样本。\n\n"
             "自定义：直接填股票代码，英文逗号分隔。",
    )
    if pool_kind.startswith("自定义"):
        pool = st.text_input(
            "股票代码（英文逗号分隔）",
            value="600519.SH,600036.SH,000858.SZ,000333.SZ,600276.SH",
            help="示例：600519.SH（贵州茅台）、000858.SZ（五粮液）。"
                 "建议 5–15 只——太少则截面标准化失去意义，太多则单只权重被过度稀释。",
        )
    else:
        pool = "HS300" if pool_kind.startswith("沪深300") else "ZZ500"

    # 时间区间：默认「上一个完整自然年」，避免区间过短导致动态权重退化
    _last_year = dt.date.today().year - 1
    c1, c2 = st.columns(2)
    with c1:
        start = st.date_input("起始日", value=dt.date(_last_year, 1, 1))
    with c2:
        end = st.date_input("截止日", value=dt.date(_last_year, 12, 31))
    _span = (end - start).days
    if _span < 180:
        st.warning(
            f"当前区间仅 {_span} 天。动态权重依赖「回看若干调仓期算因子 IC」，"
            "区间过短会导致**权重退化成等权 20%**、回测收益趋近 0，看不出动态配置的价值。"
            "建议放宽到 1 年以上（默认即上一完整自然年）。",
            icon="⚠️",
        )

    # 提前解析一次股票池，用于让 Top-N 自适应池子大小（纯函数，无副作用）
    _pool_probe = _resolve_pool(pool)
    _pool_n = max(len(_pool_probe), 1)
    if _pool_n < 2:
        st.error("股票池至少需要 2 只标的（单只无法做截面标准化，因子得分全为 0）。", icon="🚫")

    top_n = st.slider(
        "持仓 Top-N", 1, max(_pool_n, 1), min(5, max(_pool_n, 1)),
        help="**买入并持仓的标的数量**。\n\n"
             "系统会给池子里每一只都打分排名，但只买入得分最高的前 N 只，"
             "这 N 只**等权分配仓位**（每只 1/N，合计 100%）；"
             "未进前 N 的给「持有观察」或「减持」建议，不占仓位。\n\n"
             "N 越小越集中（进攻性强、波动大），N 越大越分散（稳健、收益被摊薄）。",
    )
    if _pool_n >= 2:
        st.caption(
            f"当前股票池 **{_pool_n} 只** → 买入得分最高的 **{top_n} 只**，"
            f"每只约 **{1.0/top_n:.0%}** 仓位，合计 100%；"
            f"其余 {_pool_n - top_n} 只不配置（持有观察 / 减持）。"
        )
    source_cn = st.selectbox(
        "数据源", ["合成数据（离线稳定，推荐）", "真实行情 akshare"], index=0,
        help="合成数据：内置样本，离线稳定，演示首选用这个；\n\n"
             "真实行情 akshare：尝试拉取 A 股真实行情，失败时自动回退合成数据"
             "（需本机已 pip install akshare 且网络可达）。",
    )
    source = "synthetic" if source_cn.startswith("合成") else "akshare"
    use_lg = st.checkbox("使用 LangGraph 编排", value=True,
                         help="关闭则使用内置兜底编排器（Factor/Sentiment 并行）")
    # ---- 模型配置（网页内填写；本会话 + 跨会话双重持久化）----
    # 真源是 cfg_*（非 widget key）：widget 因 toggle 收起而消失后，
    # Streamlit 会清掉 widget key（llm_*）的 state——真源放 cfg_* 才不丢。
    if not st.session_state.get("_llm_loaded", False):
        try:
            if _USER_CONFIG_PATH.exists():
                data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
                st.session_state["cfg_base_url"] = data.get("base_url", "") or ""
                st.session_state["cfg_models_raw"] = data.get("models_raw", "") or ""
                st.session_state["cfg_api_key"] = data.get("api_key", "") or ""
        except Exception:  # noqa: BLE001
            pass
        st.session_state["_llm_loaded"] = True
    st.session_state.setdefault("cfg_base_url", CONFIG.llm.base_url or "")
    st.session_state.setdefault("cfg_models_raw", CONFIG.llm.model or "")
    st.session_state.setdefault("cfg_api_key", "")

    _cfg_ok = bool(st.session_state.get("cfg_api_key"))
    show_cfg = st.toggle(
        f"⚙️ 模型配置（{'已配置 ✓' if _cfg_ok else '未配置'}）",
        key="_llm_cfg_toggle",
        help="点开填写；填完点「确认并保存」自动收起并持久化到本机",
    )
    if show_cfg:
        st.caption("同 URL 可填多个模型名（英文逗号分隔）。")
        st.text_input(
            "API Base URL", key="llm_base_url",
            value=st.session_state.get("cfg_base_url", ""),
            placeholder="https://your-openai-proxy.example.com/v1",
            on_change=_mirror_llm_cfg,
        )
        st.text_input(
            "模型名（多个用英文逗号分隔）", key="llm_models_raw",
            value=st.session_state.get("cfg_models_raw", ""),
            placeholder="glm-5.3-flash,minimax-m2.7",
            on_change=_mirror_llm_cfg,
        )
        st.text_input(
            "API Key", key="llm_api_key",
            value=st.session_state.get("cfg_api_key", ""),
            type="password", placeholder="sk-...",
            on_change=_mirror_llm_cfg,
        )
        c_conf, c_clear = st.columns([3, 1])
        with c_conf:
            # on_click 回调在 widget 实例化前执行（改 session_state 安全）；
            # click 分支里改会抛 StreamlitWidgetAlreadyInstantiatedError
            st.button("✅ 确认并保存", use_container_width=True,
                      type="primary", on_click=_on_confirm_config)
        with c_clear:
            st.button("🗑 清空", use_container_width=True,
                      help="清空三个输入框并删除本地保存的配置文件",
                      on_click=_on_clear_config)
        # 兜底落盘：即使不点确认，任何输入触发重跑时也会同步一次。
        # 清空后的一轮跳过（否则空值会把刚删的文件写回来）。
        if st.session_state.pop("_skip_persist_once", False):
            pass
        else:
            _mirror_llm_cfg()
            _persist_user_config()
    # 确认保存后的一次性成功提示
    if st.session_state.pop("_cfg_saved_msg", False):
        st.success("✅ 模型配置已保存，运行分析时生效")

    # 模型列表：网页配置优先，回退 .env 默认模型
    _raw_models = st.session_state.get("cfg_models_raw") or CONFIG.llm.model or ""
    model_list = [m.strip() for m in _raw_models.split(",") if m.strip()]
    if not model_list:
        model_list = ["（未配置，请先填模型名）"]
    llm_model = st.selectbox(
        "LLM 模型", model_list + ["离线 Mock（不调用）"], index=0,
        help="切换不同大模型生成投研结论；选「离线 Mock」则不调用任何模型，"
             "全部走确定性兜底，演示最稳定，可用于对比多模型产出差异",
    )

    _eff_key = st.session_state.get("cfg_api_key") or CONFIG.llm.api_key
    _has_key = bool(_eff_key)
    if llm_model == "离线 Mock（不调用）":
        llm_disp = "离线兜底（Mock）"
    else:
        llm_disp = (f"实时 LLM（{llm_model}）"
                    if _has_key else f"实时 LLM（{llm_model}）· 未填 Key 将降级 Mock")
    st.info(f"LLM 模式：**{llm_disp}**")
    st.caption(
        f"当前可选模型 **{len(model_list)}** 个"
        + ("（单个模型）" if len(model_list) == 1 else "")
        + "。点上方「⚙️ 模型配置」可改 URL / 模型名 / Key。"
    )

    run = st.button("运行投研链路", type="primary", use_container_width=True)

# --------------------------------------------------------------------------
# 主区：执行 + 结果渲染
# 运行结果存 session_state["result"]，下载 / 调参触发 rerun 都不会丢。
# --------------------------------------------------------------------------
# 6 个阶段的中文名，与编排器 _emit 的 step 一一对应
# 必须定义在 `if run:` 之前——进度回调 _on_progress 会引用它（NameError 坑）
STAGE_LABELS = [
    "① 数据载入 · 因子知识库检索",
    "② FactorAgent · 五类风格因子计算",
    "③ SentimentAgent · 舆情情绪研判",
    "④ ResearchAgent · 动态权重与回测",
    "⑤ RiskAgent · 规则化风控校验",
    "⑥ ReporterAgent · 报告与组合建议",
]

def _run_worker(tid: str, params: dict) -> None:
    """后台线程：执行投研链路。**禁止**调用任何 st.* 指令（无 ScriptRunContext）。"""
    def _on_progress(step, total, label):
        _tasks.add_line(tid, step, total, label)
    try:
        state = run_pipeline(
            pool=params["pool"], start=params["start"], end=params["end"],
            top_n=params["top_n"], data_source=params["source"],
            use_langgraph=params["use_lg"], on_progress=_on_progress,
        )
        _tasks.finish(tid, result=state)
    except Exception as e:  # noqa: BLE001
        _tasks.finish(tid, error=f"{type(e).__name__}: {e}")


if run:
    # 1) **先应用模型配置，再启动任务**（顺序反了会导致 Key 没装上、全程 Mock）
    _eff_base = st.session_state.get("cfg_base_url") or CONFIG.llm.base_url
    _eff_key = st.session_state.get("cfg_api_key") or CONFIG.llm.api_key
    if llm_model == "离线 Mock（不调用）":
        CONFIG.llm.enabled = False
    else:
        if _eff_base:
            CONFIG.llm.base_url = _eff_base
        if _eff_key:
            CONFIG.llm.api_key = _eff_key
        CONFIG.llm.model = llm_model
        CONFIG.llm.enabled = bool(_eff_key)
    if not CONFIG.llm.enabled:
        st.warning(
            "⚠️ 未检测到有效 API Key，本次将用离线兜底生成结论"
            "（链路、图表、回测均正常，仅「智能投研结论」为模板文本）。"
        )
    else:
        st.caption(
            f"已启用实时 LLM（{CONFIG.llm.model}）。舆情研判最多调用 "
            f"{SENTIMENT_LLM_CAP} 次大模型，推理模型较慢属正常。"
        )

    # 2) 启动后台线程执行——主线程不再同步阻塞，
    #    这样用户点左侧任何控件触发 rerun 也不会中断本次运行。
    if _tasks.has_running(st.session_state.get("task_id")):
        st.warning("已有任务在执行中，请等待其完成后再启动新的。")
    else:
        params = {
            "pool": _resolve_pool(pool),
            "start": start.strftime("%Y-%m-%d"),
            "end": end.strftime("%Y-%m-%d"),
            "top_n": top_n,
            "source": source,
            "use_lg": use_lg,
        }
        tid = _tasks.create(params)
        st.session_state["task_id"] = tid
        st.session_state.pop("result", None)      # 清掉上一轮结果
        threading.Thread(target=_run_worker, args=(tid, params),
                         daemon=True).start()
        st.rerun()

# ---- 后台任务状态：运行中渲染进度；完成后把结果转入 session_state ----
_tid = st.session_state.get("task_id")
_task = _tasks.get(_tid)
_MAX_TASK_SEC = 1800   # 单任务最长等待 30 分钟，超时停止轮询（防卡死时无限刷新）
if _task and _task["status"] == "running":
    el = time.time() - _task["t0"]
    if el > _MAX_TASK_SEC:
        st.error(f"❌ 执行超过 {_MAX_TASK_SEC//60} 分钟仍未完成，已停止等待。"
                 f"请检查模型服务是否可达，或缩小股票池 / 时间区间后重试。")
        st.stop()
    # 不再用 st.status（其可展开的右边小箭头在每秒 rerun 场景下变成"无法展开"，
    # 用户体验上像坏掉）。改为普通固定元素 + 进度条 + 计时。
    st.markdown("⏳ **投研链路执行中**（新版完成后将自动覆盖下方报告）")
    pct = min(_task["step"] / max(_task["total"], 1), 1.0)
    cur = (STAGE_LABELS[_task["step"] - 1]
           if 0 < _task["step"] <= len(STAGE_LABELS) else "准备启动…")
    st.progress(pct, text=f"正在执行（{_task['step']}/{_task['total']}）　{cur}")
    if _task["lines"]:
        st.markdown("\n".join(
            f"- ✅ {STAGE_LABELS[s-1] if 0 < s <= len(STAGE_LABELS) else lb} —— {lb}"
            for s, lb in sorted(_task["lines"], key=lambda x: x[0])))
    st.caption(f"⏱ 已用时 {el:.1f} 秒")
    time.sleep(1.0)          # 让后台线程推进
    st.rerun()
elif _task and _task["status"] == "done":
    if st.session_state.get("result") is None:
        st.session_state["result"] = _task["result"]
    st.success(f"✅ 新报告已就绪（用时 "
               f"{(_task['t_end'] or time.time()) - _task['t0']:.1f} 秒）——下方已替换")
elif _task and _task["status"] == "error":
    st.error(f"❌ 投研链路执行失败：{_task['error']}")
    st.stop()

state = st.session_state.get("result")
if state is None:
    st.info(
        "在左侧设置股票池与时间区间，点击「运行投研链路」即可生成因子评分、情绪分、"
        "动态因子权重、回测对比与可解释投研报告。默认示例为沪深 300 样本池（2025 全年）。"
    )
    st.stop()

resolved = _resolve_pool(pool)

# 应用模型配置（读持久 key cfg_*；仅用于页面信息展示——
# 链路执行前的真正应用在 sidebar 的 if run 分支里）
_eff_base = st.session_state.get("cfg_base_url") or CONFIG.llm.base_url
_eff_key = st.session_state.get("cfg_api_key") or CONFIG.llm.api_key
if llm_model == "离线 Mock（不调用）":
    CONFIG.llm.enabled = False
else:
    if _eff_base:
        CONFIG.llm.base_url = _eff_base
    if _eff_key:
        CONFIG.llm.api_key = _eff_key
    CONFIG.llm.model = llm_model
    CONFIG.llm.enabled = bool(_eff_key)
llm_state = "离线兜底（Mock）" if not CONFIG.llm.enabled else f"实时 LLM（{CONFIG.llm.model}）"

# 运行结果已存 session_state["result"]（见主区 if run 分支），
# 此处不再重复调用 run_pipeline——避免下载 PDF 等触发的 rerun 重复执行整条链路。

research = state.get("research", {})
bt = state.get("backtest", {})
risks = state.get("risks", {})
w_dyn = research.get("dynamic_weights", {})
ranking = research.get("ranking", [])

dyn_r = bt.get("dynamic", {})
sta_r = bt.get("static_equalweight", {})
eq_r = bt.get("equal_all", {})
excess = dyn_r.get("total_return", 0) - sta_r.get("total_return", 0)

# ---- 智能体执行轨迹 ----
st.subheader("智能体执行轨迹")
st.markdown(_agent_trace_html(state), unsafe_allow_html=True)
st.divider()

# ---- 顶部指标卡 ----
st.subheader("核心结论")
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("动态策略累计收益", f"{dyn_r.get('total_return',0):.1%}",
          delta=f"跑赢静态 {excess:.1%}", delta_color="normal")
m2.metric("静态等权基准累计", f"{sta_r.get('total_return',0):.1%}")
m3.metric("动态策略夏普", f"{dyn_r.get('sharpe',0):.2f}")
m4.metric("动态策略最大回撤", f"{dyn_r.get('max_drawdown',0):.1%}")
m5.metric("识别风险项", risks.get("count", 0))

st.caption(
    f"数据源：{source_cn}　|　样本区间：{start} ~ {end}（{(end-start).days} 天）　|　"
    f"股票池：{len(resolved)} 只　|　持仓 Top-{top_n}　|　LLM：{llm_state}"
)

# ---- Tabs ----
tab1, tab2, tab3, tab4 = st.tabs(["因子权重与回测", "因子·情绪·得分", "投研报告", "风险提示"])

with tab1:
    col_l, col_r = st.columns(2)
    with col_l:
        st.markdown("**动态 vs 静态 组合净值曲线**")
        if HAVE_PLOTLY:
            st.plotly_chart(chart_backtest(bt), width="stretch")
        else:
            st.line_chart(pd.DataFrame({
                "动态因子权重": bt["dynamic"]["equity"],
                "静态等权因子": bt["static_equalweight"]["equity"],
            }))
        st.caption("动态权重组合（红）相较静态等权基准（蓝）的状态适应性。"
                   "该结论回应核心研究问题：动态因子配置是否优于静态等权。")
    with col_r:
        st.markdown("**本期动态因子权重 vs 静态等权**")
        if HAVE_PLOTLY:
            st.plotly_chart(chart_weights(w_dyn, STATIC_WEIGHTS), width="stretch")
        else:
            st.bar_chart(pd.DataFrame({
                "动态权重": [w_dyn.get(f, 0) for f in FACTOR_NAMES],
                "静态等权": [STATIC_WEIGHTS[f] for f in FACTOR_NAMES],
            }, index=[FACTOR_CN[f] for f in FACTOR_NAMES]))
        # 权重表
        wt = pd.DataFrame({
            "因子": [FACTOR_CN[f] for f in FACTOR_NAMES],
            "动态权重": [w_dyn.get(f, 0) for f in FACTOR_NAMES],
            "静态等权": [STATIC_WEIGHTS[f] for f in FACTOR_NAMES],
        })
        wt["偏离"] = wt["动态权重"] - wt["静态等权"]
        st.dataframe(wt.style.format({"动态权重": "{:.1%}", "静态等权": "{:.1%}", "偏离": "{:+.1%}"}),
                     width="stretch", hide_index=True)

with tab2:
    st.markdown("**动态因子权重时序（regime 切换）**")
    if HAVE_PLOTLY and bt.get("dynamic_weights_series"):
        fig_ws = chart_weights_series(
            bt["dynamic_weights_series"], state.get("rebalance_dates", []))
        st.plotly_chart(fig_ws, width="stretch")
        st.caption("堆叠面积为各因子在每期再平衡日的权重。可见权重随市场状态（动量扩张 / 防御）"
                   "在两个倾斜方向间切换——这正是动态配置的适应性来源。")
    else:
        st.warning("当前环境未正确返回权重时序，请确认 run_pipeline 输出。")

    col_l, col_r = st.columns(2)
    with col_l:
        st.markdown(
            f"**综合得分排名（全部 {len(ranking)} 只 · 红色 = 进入组合的 Top-{top_n}）**"
        )
        if HAVE_PLOTLY and ranking:
            st.plotly_chart(chart_scores(ranking, top_n), width="stretch")
        else:
            st.dataframe(pd.DataFrame(ranking[:top_n]), width="stretch", hide_index=True)
    with col_r:
        st.markdown("**舆情情绪热力图（个股 × 再平衡日）**")
        panel = state.get("sentiment_panel", [])
        if HAVE_PLOTLY and panel:
            st.plotly_chart(chart_sentiment(panel, resolved), width="stretch")
            st.caption("红=乐观，蓝=悲观；空白为窗口内无可用舆情（走词典兜底）。")
        else:
            st.info("无情绪面板数据。")

with tab3:
    # ---- 组合建议（可执行决策，放最前）----
    advice = state.get("advice", [])
    if advice:
        st.markdown("**组合建议（可执行决策）**")
        buys = [a for a in advice if a["position"] > 0]
        if buys:
            _tot = sum(b["position"] for b in buys)
            st.success(
                "建议买入：" + "、".join(f"{b['code']}（{b['position']:.0%}）" for b in buys)
                + f"　|　合计仓位 {_tot:.0%}"
                + (f"　|　现金留存 {1-_tot:.0%}" if _tot < 0.999 else "")
                + f"　|　持有期：{buys[0]['horizon']}",
                icon="📌",
            )
            if _tot < 0.999:
                st.caption(
                    f"ℹ️ 合计未达满仓是因为部分买入标的**触发风控被降级为半仓**，"
                    f"释放的 {1-_tot:.0%} 转为现金留存，待风险缓解后再配置（非计算误差）。"
                )
        st.dataframe(
            pd.DataFrame([{
                "排名": a["rank"],
                "标的": a["code"],
                "综合得分": round(a["score"], 3),
                "情绪分": round(a["sentiment"], 2),
                "动作": a["action"],
                "建议仓位": f"{a['position']:.1%}" if a["position"] > 0 else "—",
                "依据": a["reason"],
            } for a in advice]),
            hide_index=True, width="stretch",
        )
        st.caption(
            "动作规则：综合得分进入 Top-N → **买入**（Top-N 等权分配）；"
            "未进 Top-N 且情绪 < −0.3 → **减持**；其余 → **持有观察**。"
            "命中个股级风控的买入标的自动降级为「谨慎买入」且仓位减半。"
        )
        st.divider()

    st.markdown("**智能投研报告**")
    st.markdown(state.get("report", "_无报告输出_"))

with tab4:
    st.markdown("**风险清单与降级建议**")
    rlist = risks.get("list", [])
    rdown = risks.get("downgrades", [])
    if rlist:
        for i, r in enumerate(rlist, 1):
            st.markdown(f"{i}. {r}")
    else:
        st.success("未发现显著风险，信号通过合规校验。")
    if rdown:
        st.markdown("**降级 / 对冲建议**")
        for d in rdown:
            st.markdown(f"- {d}")
    st.info(risks.get("summary", ""))

# --------------------------------------------------------------------------
# 报告下载（放在结果区最下方）：Word（可编辑）+ PDF（排版版）
# --------------------------------------------------------------------------
st.divider()
report_md = state.get("report", "")
if report_md:
    st.markdown("**下载报告**")
    col_w, col_p = st.columns(2)
    with col_w:
        docx_bytes = _report_to_docx(report_md)
        if docx_bytes:
            st.download_button(
                "下载 Word 报告", data=docx_bytes,
                file_name=f"finsage_report_{start}_{end}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True,
                help="宋体小四 + 1.5 倍行距 + 首行缩进 2 字符 + 黑体标题，可直接编辑",
            )
    with col_p:
        pdf_bytes = _report_to_pdf(report_md)
        if pdf_bytes:
            st.download_button(
                "下载 PDF 报告", data=pdf_bytes,
                file_name=f"finsage_report_{start}_{end}.pdf",
                mime="application/pdf",
                use_container_width=True,
                help="与 Word 同一套排版，适合直接分发阅读",
            )
